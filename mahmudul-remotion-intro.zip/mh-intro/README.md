# Mahmudul Hasan — Remotion intro (9:16, 64s)

Local: `npm install` then `npm start` (preview) or `npm run render` (MP4 in out/intro.mp4).
GitHub: push to a repo, open Actions > "Render video" > Run workflow, download the `intro-video` artifact.

Audio: `public/mix.mp3` is the finished mix (voice + ducked background music, 64s); originals are `voiceover.mp3` and `music.mp3`. Set `HAS_AUDIO = false` in `src/theme.ts` to render silent.
Better portrait: replace `public/portrait.png` with the high-resolution photo (same file name).
