import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {C} from './theme';
import {gradBg} from './ui';

export const Background: React.FC = () => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const blob = (x: number, y: number, s: number, c: string, ph: number): React.CSSProperties => ({
    position: 'absolute', left: x + Math.sin(frame / 60 + ph) * 70, top: y + Math.cos(frame / 75 + ph) * 90,
    width: s, height: s, borderRadius: s, background: c, filter: 'blur(90px)', opacity: 0.6,
  });
  return (
    <AbsoluteFill style={{background: `radial-gradient(900px 800px at 90% 4%, #E4D0FF, transparent 65%), radial-gradient(900px 800px at 4% 96%, #FBCFE8, transparent 65%), ${C.bg}`}}>
      <div style={blob(-180, 380, 560, '#C4B5FD', 0)} />
      <div style={blob(700, 1100, 520, '#F9A8D4', 2)} />
      <div style={blob(500, 150, 380, '#DDD6FE', 4)} />
      <div style={{position: 'absolute', left: 0, top: 0, height: 8, width: `${(frame / durationInFrames) * 100}%`, background: gradBg}} />
      <div style={{position: 'absolute', right: 70, top: 70, width: 76, height: 76, borderRadius: 24, background: gradBg, color: '#fff', fontSize: 42, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 14px 40px rgba(124,58,237,0.35)'}}>M</div>
      <div style={{position: 'absolute', left: 70, bottom: 80, background: '#fff', borderRadius: 50, padding: '20px 38px 20px 26px', fontSize: 38, fontWeight: 700, color: C.ink, display: 'flex', alignItems: 'center', gap: 18, boxShadow: '0 14px 40px rgba(124,58,237,0.15)'}}>
        <i style={{width: 34, height: 34, borderRadius: 17, background: gradBg, display: 'block'}} />
        Mahmudul Hasan · Sylhet
      </div>
    </AbsoluteFill>
  );
};
