import React from 'react';
import {Composition} from 'remotion';
import {Intro} from './Video';

export const RemotionRoot: React.FC = () => (
  <Composition id="Intro" component={Intro} durationInFrames={1920} fps={30} width={1080} height={1920} />
);
