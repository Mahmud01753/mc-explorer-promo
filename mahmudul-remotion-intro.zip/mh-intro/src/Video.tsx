import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {C, HAS_AUDIO, fontFamily} from './theme';
import {Background} from './Background';
import {Bar, Count, Icon, Pop, Portrait, Reveal, Scene, Tag, glass, gradBg, gradText, useIn} from './ui';

const Hook: React.FC = () => (
  <Scene dur={150}>
    <Tag text="Personal intro" center delay={4} />
    <Portrait size={440} delay={8} />
    <Reveal text="MAHMUDUL" delay={30} size={124} />
    <Reveal text="HASAN" delay={38} size={124} />
    <Pop delay={55} style={{alignSelf: 'center'}}>
      <div style={{fontSize: 44, fontWeight: 600, color: C.mut}}>Sylhet, Bangladesh</div>
    </Pop>
    <Pop delay={68} style={{alignSelf: 'center'}}>
      <div style={{...glass, padding: '26px 44px', borderRadius: 60, fontSize: 34, fontWeight: 700, color: C.p1}}>Cyber Security Expert · AI Prompt Engineer</div>
    </Pop>
  </Scene>
);

const Identity: React.FC = () => {
  const items: Array<['star' | 'case' | 'code', string]> = [['case', 'Entrepreneur'], ['code', 'Tech Expert'], ['star', 'Creative & AI']];
  return (
    <Scene dur={240}>
      <Tag text="Who he is" />
      {items.map(([k, t], i) => (
        <Pop key={t} delay={14 + i * 32} from={i % 2 ? 'right' : 'left'}>
          <div style={{...glass, display: 'flex', alignItems: 'center', gap: 40, padding: '56px 52px'}}>
            <Icon kind={k} />
            <div style={{fontSize: 68, fontWeight: 800, color: C.ink}}>{t}</div>
          </div>
        </Pop>
      ))}
    </Scene>
  );
};

const rows: Array<[string, string]> = [
  ['Jerin Dairy & Agro Farm', 'Owner & CEO'],
  ['M. H Global Trade', 'Owner & CEO'],
  ['Arabian International', 'CTO'],
  ['Save Sylhet Foundation', 'Volunteer'],
];

const Professions: React.FC = () => (
  <Scene dur={390}>
    <Tag text="Professions" dots />
    {rows.map(([n, r], i) => (
      <Pop key={n} delay={12 + i * 26} from={i % 2 ? 'right' : 'left'}>
        <div style={glass}>
          <div style={{fontSize: 56, fontWeight: 800, color: C.ink}}>{n}</div>
          <span style={{display: 'inline-block', marginTop: 14, background: gradBg, color: '#fff', borderRadius: 40, padding: '8px 28px', fontSize: 34, fontWeight: 700}}>{r}</span>
          <Bar delay={24 + i * 26} />
        </div>
      </Pop>
    ))}
  </Scene>
);

const DotMap: React.FC<{start: number}> = ({start}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{alignSelf: 'center', display: 'grid', gridTemplateColumns: 'repeat(8, 36px)', gap: 22, marginTop: 10}}>
      {Array.from({length: 64}).map((_, i) => {
        const lit = i < 23;
        const on = lit ? interpolate(frame, [start + i * 2, start + i * 2 + 10], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 0;
        return <div key={i} style={{width: 36, height: 36, borderRadius: 18, background: lit ? gradBg : '#DDD6FE', opacity: lit ? 0.25 + 0.75 * on : 0.55, transform: `scale(${lit ? 0.8 + 0.2 * on : 1})`}} />;
      })}
    </div>
  );
};

const Kpi: React.FC<{to: number; suffix?: string; label: string; delay: number; alt?: boolean}> = ({to, suffix, label, delay, alt}) => (
  <Pop delay={delay}>
    <div style={{...glass, textAlign: 'center', padding: '54px 20px'}}>
      <div style={{fontSize: 104, fontWeight: 800, lineHeight: 1, color: alt ? C.p2 : C.p1}}>
        <Count to={to} suffix={suffix} start={delay + 8} />
      </div>
      <div style={{fontSize: 40, fontWeight: 600, color: C.mut, marginTop: 14}}>{label}</div>
    </div>
  </Pop>
);

const Travel: React.FC = () => (
  <Scene dur={270}>
    <Tag text="Travel" />
    <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 30}}>
      <Kpi to={23} label="Districts" delay={10} />
      <Kpi to={36} suffix="%" label="of Bangladesh" delay={22} alt />
      <Kpi to={113} label="Upazilas" delay={34} />
      <Kpi to={7} label="Countries" delay={46} alt />
    </div>
    <DotMap start={70} />
  </Scene>
);

const Skills: React.FC = () => {
  const skills = [
    'Cyber Security Expert',
    'Digital Marketer · Google Certified',
    'Graphic Designer',
    'Vibe Coder',
    'AI Prompt Engineer',
    'Web Design & Development',
    'Visa Processing Expert',
    'Mobile Flash & Unlock',
    'Advanced AI User',
  ];
  const langs = ['Bangla', 'English', 'Mandarin', 'Hindi', 'Urdu', 'Arabic'];
  const chip: React.CSSProperties = {borderRadius: 60, padding: '18px 34px', fontSize: 36, fontWeight: 700};
  return (
    <Scene dur={480}>
      <Tag text="Expertise" />
      <div style={{display: 'flex', flexWrap: 'wrap', gap: 18}}>
        {skills.map((s, i) => (
          <Pop key={s} delay={10 + i * 26}>
            <div style={{...chip, background: gradBg, color: '#fff', boxShadow: '0 14px 34px rgba(124,58,237,0.3)'}}>{s}</div>
          </Pop>
        ))}
      </div>
      <Pop delay={270}>
        <div style={glass}>
          <div style={{fontSize: 70, fontWeight: 800, ...gradText}}>6 Languages</div>
          <div style={{display: 'flex', flexWrap: 'wrap', gap: 18, marginTop: 30}}>
            {langs.map((l, i) => (
              <Pop key={l} delay={286 + i * 10}>
                <div style={{...chip, fontSize: 40, background: '#fff', border: '2px solid #E9D5FF', color: C.ink}}>{l}</div>
              </Pop>
            ))}
          </div>
        </div>
      </Pop>
    </Scene>
  );
};

const Education: React.FC = () => {
  const frame = useCurrentFrame();
  const steps = ['Kalrarukha Dakhil Madrasah', 'Sylhet Govt. Alia Madrasah', 'MC College, Sylhet'];
  const line = interpolate(frame, [10, 120], [0, 100], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <Scene dur={210}>
      <Tag text="Education" />
      <div style={{position: 'relative', paddingLeft: 80, display: 'flex', flexDirection: 'column', gap: 40}}>
        <div style={{position: 'absolute', left: 22, top: 30, bottom: 30, width: 8, borderRadius: 4, background: '#E9D5FF'}}>
          <div style={{width: '100%', height: `${line}%`, borderRadius: 4, background: gradBg}} />
        </div>
        {steps.map((s, i) => (
          <Pop key={s} delay={18 + i * 34} from="right">
            <div style={{...glass, position: 'relative', fontSize: 50, fontWeight: 700, color: C.ink}}>
              <div style={{position: 'absolute', left: -72, top: '50%', marginTop: -20, width: 40, height: 40, borderRadius: 20, background: gradBg, boxShadow: `0 0 0 10px ${C.bg}`}} />
              {s}
            </div>
          </Pop>
        ))}
      </div>
    </Scene>
  );
};

const End: React.FC = () => {
  const frame = useCurrentFrame();
  const pulse = 1 + 0.035 * Math.sin(frame / 6);
  const p = useIn(40, 12);
  return (
    <Scene dur={180} fadeOut={false}>
      <Portrait size={340} delay={2} />
      <Reveal text="Mahmudul Hasan" delay={22} size={96} />
      <Pop delay={34} style={{alignSelf: 'center'}}>
        <div style={{fontSize: 44, fontWeight: 600, color: C.mut}}>Sylhet</div>
      </Pop>
      <div style={{alignSelf: 'center', opacity: Math.min(1, p * 2), transform: `scale(${(0.7 + 0.3 * p) * pulse})`}}>
        <div style={{background: gradBg, color: '#fff', fontSize: 62, fontWeight: 800, borderRadius: 80, padding: '38px 80px', boxShadow: '0 30px 70px rgba(124,58,237,0.45)'}}>Follow the journey.</div>
      </div>
    </Scene>
  );
};

export const Intro: React.FC = () => (
  <AbsoluteFill style={{fontFamily}}>
    <Background />
    <Sequence from={0} durationInFrames={150}><Hook /></Sequence>
    <Sequence from={150} durationInFrames={240}><Identity /></Sequence>
    <Sequence from={390} durationInFrames={390}><Professions /></Sequence>
    <Sequence from={780} durationInFrames={270}><Travel /></Sequence>
    <Sequence from={1050} durationInFrames={480}><Skills /></Sequence>
    <Sequence from={1530} durationInFrames={210}><Education /></Sequence>
    <Sequence from={1740} durationInFrames={180}><End /></Sequence>
    {HAS_AUDIO && <Audio src={staticFile('mix.mp3')} />}
  </AbsoluteFill>
);
