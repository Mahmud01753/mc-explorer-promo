import {loadFont} from '@remotion/google-fonts/Inter';

export const {fontFamily} = loadFont('normal', {weights: ['400', '600', '700', '800'], subsets: ['latin']});

export const C = {bg: '#F6F2FF', ink: '#1B1340', mut: '#6B6591', p1: '#7C3AED', p2: '#D946EF'};
export const HAS_AUDIO = true; // public/mix.mp3 = voice + ducked music (64s)
