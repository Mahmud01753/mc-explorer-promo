import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {C} from './theme';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

export const gradBg = `linear-gradient(135deg, ${C.p1}, ${C.p2})`;
export const gradText: React.CSSProperties = {
  background: `linear-gradient(90deg, ${C.ink} 10%, ${C.p1} 60%, ${C.p2})`,
  WebkitBackgroundClip: 'text',
  backgroundClip: 'text',
  color: 'transparent',
};
export const glass: React.CSSProperties = {
  background: 'rgba(255,255,255,0.78)',
  backdropFilter: 'blur(24px)',
  border: '3px solid #fff',
  borderRadius: 48,
  padding: '44px 52px',
  boxShadow: '0 30px 70px rgba(124,58,237,0.18)',
};

export const useIn = (delay = 0, damping = 13) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: frame - delay, fps, config: {damping, stiffness: 110, mass: 0.9}});
};

export const Pop: React.FC<{delay?: number; from?: 'up' | 'left' | 'right'; style?: React.CSSProperties; children: React.ReactNode}> = ({
  delay = 0, from = 'up', style, children,
}) => {
  const p = useIn(delay);
  const x = from === 'left' ? (1 - p) * -180 : from === 'right' ? (1 - p) * 180 : 0;
  const y = from === 'up' ? (1 - p) * 100 : 0;
  const o = Math.max(0, Math.min(1, p * 1.8));
  return <div style={{opacity: o, transform: `translate(${x}px, ${y}px) scale(${0.9 + 0.1 * p})`, ...style}}>{children}</div>;
};

export const Tag: React.FC<{text: string; delay?: number; dots?: boolean; center?: boolean}> = ({text, delay = 0, dots, center}) => (
  <Pop delay={delay} style={{alignSelf: center ? 'center' : 'flex-start'}}>
    <div style={{display: 'flex', alignItems: 'center', gap: 18, background: '#fff', borderRadius: 60, padding: '16px 36px', fontSize: 34, fontWeight: 800, color: C.p1, boxShadow: '0 12px 34px rgba(124,58,237,0.2)'}}>
      {dots && (
        <span style={{display: 'flex', gap: 10}}>
          {['#ff5f57', '#febc2e', '#28c840'].map((c) => (
            <i key={c} style={{width: 20, height: 20, borderRadius: 10, background: c, display: 'block'}} />
          ))}
        </span>
      )}
      {text}
    </div>
  </Pop>
);

export const Scene: React.FC<{dur: number; fadeOut?: boolean; children: React.ReactNode}> = ({dur, fadeOut = true, children}) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [0, 14, dur - 14, dur], [0, 1, 1, fadeOut ? 0 : 1], clamp);
  const s = interpolate(frame, [0, dur], [1, 1.035], clamp);
  return (
    <AbsoluteFill style={{opacity: o, padding: '200px 80px 250px', justifyContent: 'center', gap: 40, transform: `scale(${s})`}}>{children}</AbsoluteFill>
  );
};

export const Count: React.FC<{to: number; start: number; suffix?: string; style?: React.CSSProperties}> = ({to, start, suffix = '', style}) => {
  const frame = useCurrentFrame();
  const v = Math.round(interpolate(frame, [start, start + 50], [0, to], {...clamp, easing: Easing.out(Easing.cubic)}));
  return <span style={style}>{v}{suffix}</span>;
};

export const Bar: React.FC<{delay: number}> = ({delay}) => {
  const frame = useCurrentFrame();
  const w = interpolate(frame, [delay, delay + 28], [0, 100], {...clamp, easing: Easing.out(Easing.cubic)});
  return (
    <div style={{height: 14, borderRadius: 7, background: '#EDE9FE', marginTop: 26, overflow: 'hidden'}}>
      <div style={{height: '100%', width: `${w}%`, borderRadius: 7, background: gradBg}} />
    </div>
  );
};

export const Portrait: React.FC<{size: number; delay?: number}> = ({size, delay = 0}) => {
  const frame = useCurrentFrame();
  const p = useIn(delay, 16);
  const box = size + 90;
  const R = size / 2 + 24;
  const circ = 2 * Math.PI * R;
  const draw = interpolate(frame - delay, [0, 45], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  const float = Math.sin(frame / 18) * 10;
  return (
    <div style={{position: 'relative', width: size, height: size, alignSelf: 'center', opacity: Math.min(1, p * 2), transform: `translateY(${float}px) scale(${0.6 + 0.4 * p})`}}>
      <svg width={box} height={box} style={{position: 'absolute', left: -45, top: -45}}>
        <defs>
          <linearGradient id="pg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor={C.p1} />
            <stop offset="1" stopColor={C.p2} />
          </linearGradient>
        </defs>
        <circle cx={box / 2} cy={box / 2} r={R} fill="none" stroke="url(#pg)" strokeWidth={10} strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={circ * (1 - draw)} transform={`rotate(-90 ${box / 2} ${box / 2})`} />
      </svg>
      <Img src={staticFile('portrait.png')} style={{width: size, height: size, boxSizing: 'border-box', borderRadius: '50%', objectFit: 'cover', border: '12px solid #fff', boxShadow: '0 40px 90px rgba(124,58,237,0.35)'}} />
    </div>
  );
};

export const Reveal: React.FC<{text: string; delay: number; size: number}> = ({text, delay, size}) => {
  const p = useIn(delay, 15);
  return (
    <div style={{overflow: 'hidden', textAlign: 'center', paddingBottom: 12}}>
      <div style={{transform: `translateY(${(1 - p) * 115}%)`, fontSize: size, lineHeight: 1.05, fontWeight: 800, letterSpacing: -3, ...gradText}}>{text}</div>
    </div>
  );
};

export const Icon: React.FC<{kind: 'star' | 'case' | 'code'}> = ({kind}) => (
  <div style={{width: 112, height: 112, borderRadius: 34, background: gradBg, display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none', boxShadow: '0 16px 40px rgba(124,58,237,0.35)'}}>
    <svg width={60} height={60} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      {kind === 'star' && <polygon points="12,2 15,9 22,9.5 17,14.5 18.5,22 12,18 5.5,22 7,14.5 2,9.5 9,9" />}
      {kind === 'case' && (<><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2" /></>)}
      {kind === 'code' && (<><polyline points="8,6 2,12 8,18" /><polyline points="16,6 22,12 16,18" /></>)}
    </svg>
  </div>
);
