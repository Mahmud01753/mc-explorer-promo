# Mahmudul Hasan Ad — গিটহাবে MP4 রেন্ডার

## ফাইল
- `Final_Mahmudul_Hasan_Ad_Storyboard_v66.html` — স্টোরিবোর্ড (ফ্রেম ও অ্যানিমেশন)
- `Mahmudul_Hasan_Ad_Final_Mix_VO_plus_Sound.mp3` — ফাইনাল অডিও (ভয়েসওভার + ব্যাকগ্রাউন্ড সাউন্ড)
- `render.py` — ভার্চুয়াল ক্লকে প্রতিটা ফ্রেম ধরে MP4 বানায় (ফ্রেম ও টাইমিং একদম নির্দিষ্ট থাকে)
- `.github/workflows/render.yml` — গিটহাব অ্যাকশনস ওয়ার্কফ্লো

## গিটহাবে চালানো
1. এই ফোল্ডারের সব ফাইল একটা নতুন রিপোজিটরিতে আপলোড করুন (ফাইলগুলো রিপোর রুটে থাকবে)।
2. রিপোজিটরিতে **Actions** ট্যাব > **Render storyboard MP4** > **Run workflow** চাপুন।
3. প্রায় ৩০-৪০ মিনিট পর রানটি শেষ হলে নিচে **Artifacts** থেকে `mahmudul-hasan-ad` ডাউনলোড করুন। ভিতরে `mahmudul_hasan_ad.mp4` থাকবে।

## লোকালি চালাতে (ঐচ্ছিক)
```
pip install playwright && python -m playwright install chromium
python render.py
```
ffmpeg লাগবে। ছোট পরীক্ষা: `W=640 LIMIT=10 python render.py` (প্রথম ১০ সেকেন্ড, ৬৪০×৩৬০)।

## সেটিংস (env)
- `W` — প্রস্থ (ডিফল্ট 1920; 640-এর গুণিতক হতে হবে, যেমন 1280)
- `FPS` — ডিফল্ট 30
- `FADE_OUT` — শেষে ফেড-আউট সেকেন্ড (ডিফল্ট 1.4)
- `TEST_TIMES` — যেমন `TEST_TIMES=8,20,60` দিলে ভিডিও না বানিয়ে ওই সময়ের ছবি `test_frames/`-এ যাবে
