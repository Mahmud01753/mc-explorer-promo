"""
Mahmudul Hasan ad storyboard -> MP4 renderer.

Drives the HTML player with a virtual clock (so every frame is exact, not
real-time), screenshots the #stage player for every frame, and pipes the
frames straight into ffmpeg together with the final audio mix.

Env vars (all optional):
  HTML        storyboard file            (default: Final_Mahmudul_Hasan_Ad_Storyboard_v66.html)
  AUDIO       final audio mix            (default: Mahmudul_Hasan_Ad_Final_Mix_VO_plus_Sound.mp3)
  OUT         output mp4                 (default: output/mahmudul_hasan_ad.mp4)
  W, H        output size                (default: 1920 x 1080)
  FPS         frames per second          (default: 30)
  FADE_OUT    fade-out seconds at end    (default: 1.4)
  LIMIT       render only first N secs   (for a quick test run)
  TEST_TIMES  comma list of seconds (e.g. "0.5,10,30"): save PNG stills to
              test_frames/ instead of rendering the video
"""
import os, json, subprocess, sys
from playwright.sync_api import sync_playwright

HTML = os.environ.get("HTML", "Final_Mahmudul_Hasan_Ad_Storyboard_v66.html")
AUDIO = os.environ.get("AUDIO", "Mahmudul_Hasan_Ad_Final_Mix_VO_plus_Sound.mp3")
OUT = os.environ.get("OUT", "output/mahmudul_hasan_ad.mp4")
W = int(os.environ.get("W", 1920))
H = int(os.environ.get("H", 1080))
FPS = int(os.environ.get("FPS", 30))
FADE_OUT = float(os.environ.get("FADE_OUT", 1.4))
TEST_TIMES = os.environ.get("TEST_TIMES", "").strip()

# Virtual clock: replaces performance.now, requestAnimationFrame, setTimeout,
# and the Web Audio API (silent stub; the sound comes from AUDIO instead).
# CSS / Web Animations are driven by setting document.getAnimations() currentTime.
INIT_JS = r"""
(function () {
  const TOP = window.top;
  if (!TOP.__vt) TOP.__vt = { now: 0, q: [], tm: [], id: 1 };
  const V = TOP.__vt;
  performance.now = function () { return V.now; };
  window.requestAnimationFrame = function (cb) { const id = V.id++; V.q.push([id, cb]); return id; };
  window.cancelAnimationFrame = function (id) { V.q = V.q.filter(x => x[0] !== id); };
  window.setTimeout = function (fn, ms) { const id = V.id++; V.tm.push({ id: id, d: V.now + (+ms || 0), fn: fn }); return id; };
  window.clearTimeout = function (id) { V.tm = V.tm.filter(x => x.id !== id); };
  const mk = function () {
    return new Proxy(function () {}, {
      get(t, p) {
        if (p === Symbol.toPrimitive) return () => 0;
        if (p === 'sampleRate') return 44100;
        if (p === 'currentTime') return V.now / 1000;
        if (p === 'then') return undefined;
        return mk();
      },
      set() { return true; },
      apply() { return mk(); },
      construct() { return mk(); }
    });
  };
  window.AudioContext = mk();
  window.webkitAudioContext = window.AudioContext;
  if (window === TOP) {
    TOP.__step = function (sec) {
      // sec = seconds of video time; the page's clock (performance.now, rAF) is in ms.
      const t = sec * 1000;
      V.now = t;
      // timers due at or before t
      for (let g = 0; g < 10000; g++) {
        const due = V.tm.filter(x => x.d <= t).sort((a, b) => a.d - b.d || a.id - b.id);
        if (!due.length) break;
        const x = due[0];
        V.tm = V.tm.filter(y => y !== x);
        try { x.fn(); } catch (e) { console.error(e); }
      }
      // one animation frame per step
      const cur = V.q; V.q = [];
      for (const item of cur) { try { item[1](t); } catch (e) { console.error(e); } }
      // CSS + Web Animations in the main doc and every iframe (currentTime is in ms)
      const docs = [document];
      document.querySelectorAll('iframe').forEach(f => { try { if (f.contentDocument) docs.push(f.contentDocument); } catch (e) {} });
      docs.forEach(d => {
        try {
          d.getAnimations({ subtree: true }).forEach(a => { a.pause(); a.currentTime = t; });
        } catch (e) {}
      });
      return V.q.length;
    };
  }
})();
"""

def audio_duration(path):
    out = subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                   "-of", "default=nw=1:nk=1", path]).decode().strip()
    return float(out)


SIG_JS = "document.getElementById('stage').innerHTML.length + '|' + document.querySelectorAll('#stage iframe').length"
# An srcdoc frame's inline scripts run as soon as its <body> is parsed, so "body present" is enough.
READY_JS = ("() => [...document.querySelectorAll('#stage iframe')].every(f => { try { "
            "const d = f.contentDocument; return !d || (d.body && d.readyState !== 'loading'); } catch (e) { return true; } })")

def advance(page, t):
    """Move the virtual clock to t. If a new storyboard frame (iframe) was inserted,
    let it finish loading (its scripts read the clock) and then re-sync to t."""
    before = page.evaluate(SIG_JS)
    page.evaluate("t => __step(t)", t)
    if page.evaluate(SIG_JS) != before:
        try:
            page.wait_for_function(READY_JS, polling=20, timeout=15000)
        except Exception as e:
            print("warning: frame iframe slow to load:", str(e)[:120], flush=True)
        page.evaluate("t => __step(t)", t)

def main():
    html_path = os.path.abspath(HTML)
    if TEST_TIMES:
        times = [float(x) for x in TEST_TIMES.split(",")]
        dur = None
    else:
        dur = audio_duration(AUDIO)
        if os.environ.get("LIMIT"):          # quick test: render only the first N seconds
            dur = min(dur, float(os.environ["LIMIT"]))
        times = None

    os.makedirs("test_frames" if TEST_TIMES else os.path.dirname(OUT) or ".", exist_ok=True)

    ff = None
    if not TEST_TIMES:
        ff = subprocess.Popen([
            "ffmpeg", "-y", "-loglevel", "error",
            "-f", "image2pipe", "-framerate", str(FPS), "-c:v", "png", "-i", "-",
            "-i", os.path.abspath(AUDIO),
            "-map", "0:v", "-map", "1:a",
            "-t", f"{dur:.3f}",
            "-vf", f"fade=t=out:st={dur - FADE_OUT:.3f}:d={FADE_OUT},format=yuv420p",
            "-af", f"afade=t=out:st={dur - FADE_OUT:.3f}:d={FADE_OUT}",
            "-c:v", "libx264", "-preset", "medium", "-crf", "18",
            "-c:a", "aac", "-b:a", "256k", "-movflags", "+faststart",
            OUT
        ], stdin=subprocess.PIPE)

    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--autoplay-policy=no-user-gesture-required"])
        # The player is a fixed 640x360 (16:9) block; scale it up to W x H.
        page = browser.new_page(viewport={"width": 640, "height": 800}, device_scale_factor=W / 640)
        page.add_init_script(INIT_JS)
        page.goto("file://" + html_path, wait_until="load")
        page.evaluate("document.fonts && document.fonts.ready.then(()=>1)")

        # Lock the player to exactly 640x360 so the screenshot is exactly W x H after scaling.
        page.add_style_tag(content="#pl{width:640px!important;max-width:640px!important;padding:0!important;margin:0!important}"
                                   "#stage{width:640px!important;height:360px!important}")
        page.wait_for_timeout(300)
        bb = page.locator("#stage").bounding_box()
        print("stage box:", bb, flush=True)
        page.evaluate("__step(0)")
        page.evaluate("typeof play==='function' && play(-1)")

        stage = page.locator("#stage")

        if TEST_TIMES:
            os.makedirs("test_frames", exist_ok=True)
            for t in times:
                advance(page, t)
                fn = f"test_frames/t_{t:06.2f}.png"
                stage.screenshot(path=fn)
                print("saved", fn, flush=True)
        else:
            n = int(round(dur * FPS))
            for i in range(n):
                t = i / FPS
                advance(page, t)
                ff.stdin.write(stage.screenshot(type="png"))
                if i % (FPS * 10) == 0:
                    print(f"frame {i}/{n}  t={t:.1f}s", flush=True)
        browser.close()

    if ff:
        ff.stdin.close()
        ff.wait()
        print("done:", OUT, flush=True)

if __name__ == "__main__":
    main()
