# MC Explorer - 30s promo (Remotion)
1080x1920 (9:16), 30 fps, 900 frames. Site: mc-explorer.top

    npm install
    npm start          # live preview (Remotion Studio)
    npm run build      # renders out/mc-explorer-promo.mp4
    npm run still      # thumbnail PNG

Scenes: 0-4s hook (zoom guess) | 4-9s brand | 9-16s how to play | 16-21s score + leaderboard
        21-25.5s weekly prize | 25.5-30s call to action
All text: src/content.ts   Colors/timing: src/theme.ts   Photos/logo: public/
Fonts (Anek Bangla, Poppins) load from Google Fonts at render time -> internet needed on first run.

## Voice-over
public/voice/voiceover.mp3 (30s Bengali) plays from frame 0 (see src/voice.json).
Turn off: VOICE_ENABLED=false in src/theme.ts.

## Music
public/music/music.mp3 (40s, only first 30s used). Drop at 4.0s, hits at 21.0s and 25.5s match the scene cuts.
It ducks under the voice automatically (src/music.ts) and fades out at 29-30s. Turn off: MUSIC_ENABLED=false in src/theme.ts.

## Render on GitHub (no local setup)
Push this folder to a NEW repo -> Actions tab -> "Render promo video" -> Run workflow
-> open the finished run -> download the "mc-explorer-promo" artifact (zip containing the MP4).
