import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import voice from './voice.json';
import {Background} from './components/Background';
import {CircleWipe} from './components/CircleWipe';
import {TopTag} from './components/TopTag';
import {Hook} from './scenes/Hook';
import {Brand} from './scenes/Brand';
import {Steps} from './scenes/Steps';
import {Score} from './scenes/Score';
import {Prize} from './scenes/Prize';
import {CTA} from './scenes/CTA';
import {C, S, TOTAL, VOICE_ENABLED, MUSIC_ENABLED} from './theme';
import {musicVolume} from './music';

const CUTS = [S.brand.from, S.steps.from, S.score.from, S.prize.from, S.cta.from];

export const Promo: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Background />

      <Sequence from={S.hook.from} durationInFrames={S.hook.d}>
        <Hook />
      </Sequence>
      <Sequence from={S.brand.from} durationInFrames={S.brand.d}>
        <Brand />
      </Sequence>
      <Sequence from={S.steps.from} durationInFrames={S.steps.d}>
        <Steps />
      </Sequence>
      <Sequence from={S.score.from} durationInFrames={S.score.d}>
        <Score />
      </Sequence>
      <Sequence from={S.prize.from} durationInFrames={S.prize.d}>
        <Prize />
      </Sequence>
      <Sequence from={S.cta.from} durationInFrames={S.cta.d}>
        <CTA />
      </Sequence>

      <Sequence
        from={S.steps.from}
        durationInFrames={S.prize.from + S.prize.d - S.steps.from}
      >
        <TopTag duration={S.prize.from + S.prize.d - S.steps.from} />
      </Sequence>

      {CUTS.map((b) => (
        <Sequence key={b} from={b - 10} durationInFrames={24}>
          <CircleWipe />
        </Sequence>
      ))}

      {VOICE_ENABLED &&
        voice.map((v) => (
          <Sequence key={v.file} from={v.from}>
            <Audio src={staticFile(`voice/${v.file}.mp3`)} />
          </Sequence>
        ))}

      {MUSIC_ENABLED && (
        <Audio src={staticFile('music/music.mp3')} volume={(f) => musicVolume(f)} />
      )}

      {/* thin progress bar */}
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          height: 8,
          width: `${(f / TOTAL) * 100}%`,
          background: C.yellow,
          boxShadow: '0 0 20px rgba(255,210,63,0.8)',
        }}
      />
    </AbsoluteFill>
  );
};
