import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {C} from '../theme';

const BLOBS = [
  {x: 180, y: 300, s: 760, p: 0},
  {x: 920, y: 1000, s: 860, p: 2},
  {x: 300, y: 1700, s: 760, p: 4},
];

export const Background: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        background: `linear-gradient(165deg, ${C.green0} 0%, ${C.green1} 45%, ${C.green2} 100%)`,
      }}
    >
      {BLOBS.map((b, i) => (
        <div
          key={i}
          style={{
            position: 'absolute',
            left: b.x - b.s / 2 + Math.sin(f / 50 + b.p) * 70,
            top: b.y - b.s / 2 + Math.cos(f / 60 + b.p) * 70,
            width: b.s,
            height: b.s,
            borderRadius: '50%',
            background:
              'radial-gradient(circle, rgba(255,210,63,0.16) 0%, rgba(255,210,63,0) 65%)',
          }}
        />
      ))}
      <AbsoluteFill
        style={{
          backgroundImage:
            'radial-gradient(rgba(255,255,255,0.10) 2px, transparent 2px)',
          backgroundSize: '60px 60px',
          backgroundPosition: `${f * 0.5}px ${f * 0.5}px`,
          opacity: 0.6,
        }}
      />
    </AbsoluteFill>
  );
};
