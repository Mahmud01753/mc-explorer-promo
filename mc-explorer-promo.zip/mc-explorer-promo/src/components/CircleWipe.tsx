import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {C} from '../theme';

// 24-frame yellow circle transition. Local frame 10 = the scene cut.
export const CircleWipe: React.FC = () => {
  const f = useCurrentFrame();
  const R = 1500;

  if (f < 10) {
    const r = interpolate(f, [0, 10], [0, R], {
      easing: Easing.in(Easing.cubic),
      extrapolateRight: 'clamp',
    });
    return (
      <AbsoluteFill style={{overflow: 'hidden'}}>
        <div
          style={{
            position: 'absolute',
            left: 540 - r,
            top: 960 - r,
            width: r * 2,
            height: r * 2,
            borderRadius: '50%',
            background: C.yellow,
          }}
        />
      </AbsoluteFill>
    );
  }

  const r = interpolate(f, [10, 24], [0, R], {
    easing: Easing.out(Easing.cubic),
    extrapolateRight: 'clamp',
  });
  return (
    <AbsoluteFill style={{overflow: 'hidden'}}>
      <div
        style={{
          position: 'absolute',
          left: 540 - r,
          top: 960 - r,
          width: r * 2,
          height: r * 2,
          borderRadius: '50%',
          boxShadow: `0 0 0 3200px ${C.yellow}`,
        }}
      />
    </AbsoluteFill>
  );
};
