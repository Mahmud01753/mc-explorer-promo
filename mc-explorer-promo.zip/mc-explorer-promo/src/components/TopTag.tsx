import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {C} from '../theme';
import {en} from '../fonts';
import {content} from '../content';
import {clamp} from '../utils';

export const TopTag: React.FC<{duration: number}> = ({duration}) => {
  const f = useCurrentFrame();
  const o = interpolate(f, [0, 12, duration - 12, duration], [0, 1, 1, 0], clamp);
  return (
    <AbsoluteFill style={{alignItems: 'center', opacity: o}}>
      <div
        style={{
          marginTop: 150,
          padding: '12px 34px',
          borderRadius: 60,
          background: 'rgba(0,0,0,0.28)',
          border: '2px solid rgba(255,255,255,0.18)',
          color: C.mut,
          fontFamily: en,
          fontWeight: 600,
          fontSize: 32,
          letterSpacing: 1,
        }}
      >
        MC EXPLORER ·{' '}
        <span style={{color: C.yellow}}>{content.site}</span>
      </div>
    </AbsoluteFill>
  );
};
