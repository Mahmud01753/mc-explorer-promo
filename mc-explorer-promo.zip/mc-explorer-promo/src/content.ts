// All on-screen text lives here - edit freely.
export const content = {
  site: 'mc-explorer.top',
  college: 'Murari Chand College · Sylhet',

  hook: {
    l1: 'এই জায়গাটা',
    l2: 'কোথায় বলো তো?',
    answer: 'মুরারিচাঁদ কলেজ',
  },

  tagline: ['Guess.', 'Zoom.', 'Compete.'],

  stepsTitle: 'কীভাবে খেলবে?',
  steps: [
    {title: 'ছবি দেখে অনুমান করো', sub: 'জুম করা জায়গাটা কলেজের কোথায়?'},
    {title: '১০টি প্রশ্নে স্কোর', sub: 'তুমি কলেজ কতটুকু চেনো — জেনে নাও'},
    {title: 'কার্ড শেয়ার করো', sub: 'বন্ধুকে চ্যালেঞ্জ দাও, সবার আগে থাকো'},
  ],

  scoreTitle: 'তোমার MC স্কোর কত?',
  boardTitle: 'লিডারবোর্ড',
  // sample data for the animation only
  board: [
    {name: 'Explorer 01', score: 10},
    {name: 'Explorer 02', score: 9},
    {name: 'Explorer 03', score: 9},
    {name: 'Explorer 04', score: 8},
    {name: 'Explorer 05', score: 7},
  ],

  prize: {
    l1: 'প্রতি সপ্তাহে লটারির মাধ্যমে',
    winners: 5,
    l2suffix: 'জন বিজয়ী',
    l3: 'পুরস্কার পাবেন!',
    chips: ['শেয়ার করুন', 'ফর্ম জমা দিন', 'জিতে নিন'],
  },

  cta: {
    big: 'এখনই খেলো!',
    sub: 'তুমি কলেজ কতটুকু চেনো?',
    challenge: 'বন্ধুকেও চ্যালেঞ্জ দাও!',
  },
};
