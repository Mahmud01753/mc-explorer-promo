import {loadFont as loadAnek} from '@remotion/google-fonts/AnekBangla';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';

// Bengali UI font (same family the site uses) + Latin display font
export const bn = loadAnek('normal', {
  weights: ['600', '800'],
  subsets: ['bengali', 'latin'],
}).fontFamily;

export const en = loadPoppins('normal', {
  weights: ['600', '700', '800'],
  subsets: ['latin'],
}).fontFamily;
