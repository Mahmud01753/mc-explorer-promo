import {interpolate} from 'remotion';
import {FPS} from './theme';
import {clamp} from './utils';

// When the voice-over is speaking (seconds). Music ducks under these parts.
export const SPEECH: [number, number][] = [
  [0.5, 3.12],
  [4.63, 7.83],
  [9.5, 13.86],
  [16.58, 17.74],
  [21.54, 24.86],
  [26.19, 28.6],
];

const FULL = 0.8; // music volume in the gaps / on the hits
const DUCK = 0.4; // music volume while the voice speaks

// frame -> music volume (0..1). Ducks under speech, fades out in the last second.
export const musicVolume = (f: number) => {
  const t = f / FPS;
  let duck = 0;
  for (const [s, e] of SPEECH) {
    const d =
      t < s
        ? interpolate(t, [s - 0.3, s], [0, 1], clamp)
        : interpolate(t, [e, e + 0.5], [1, 0], clamp);
    duck = Math.max(duck, d);
  }
  const fade = interpolate(t, [29, 30], [1, 0], clamp);
  return interpolate(duck, [0, 1], [FULL, DUCK]) * fade;
};
