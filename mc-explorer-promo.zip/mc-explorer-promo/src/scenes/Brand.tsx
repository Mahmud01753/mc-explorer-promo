import React from 'react';
import {
  AbsoluteFill,
  Img,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {C} from '../theme';
import {bn, en} from '../fonts';
import {content} from '../content';
import {clamp} from '../utils';

const PHOTOS = [
  {src: 'academic.jpg', x: 540, y: 1400, d: 400, delay: 20},
  {src: 'gate1.jpg', x: 170, y: 1260, d: 230, delay: 30},
  {src: 'library.jpg', x: 910, y: 1260, d: 230, delay: 36},
  {src: 'chem.jpg', x: 200, y: 1640, d: 230, delay: 42},
  {src: 'mohona.jpg', x: 880, y: 1640, d: 230, delay: 48},
];

const TITLE = 'MC EXPLORER'.split('');

export const Brand: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();

  const disc = spring({frame: f - 4, fps, durationInFrames: 34, config: {damping: 200}});
  const logo = spring({frame: f - 12, fps, config: {damping: 9, stiffness: 110}});
  const pill = spring({frame: f - 74, fps, config: {damping: 12}});
  const college = interpolate(f, [64, 84], [0, 1], clamp);
  const glow = 0.5 + Math.sin(f / 10) * 0.2;

  return (
    <AbsoluteFill>
      {/* big yellow arc (like the site's share banner) */}
      <div
        style={{
          position: 'absolute',
          left: 540 - 1100,
          top: 2050 - 1100,
          width: 2200,
          height: 2200,
          borderRadius: '50%',
          background: C.yellow,
          transform: `scale(${disc})`,
        }}
      />

      <div style={{position: 'absolute', top: 150, left: 0, right: 0, display: 'flex', justifyContent: 'center'}}>
        <Img
          src={staticFile('logo.png')}
          style={{
            width: 310,
            height: 310,
            transform: `translateY(${(1 - logo) * -520}px) scale(${0.6 + 0.4 * logo})`,
            filter: `drop-shadow(0 0 ${40 * glow}px rgba(255,210,63,0.7))`,
          }}
        />
      </div>

      <div
        style={{
          position: 'absolute',
          top: 470,
          width: '100%',
          display: 'flex',
          justifyContent: 'center',
          fontFamily: en,
          fontWeight: 800,
          fontSize: 120,
          color: C.white,
          letterSpacing: 2,
        }}
      >
        {TITLE.map((ch, i) => {
          const s = spring({frame: f - 30 - i * 3, fps, config: {damping: 12}});
          return (
            <span
              key={i}
              style={{
                display: 'inline-block',
                whiteSpace: 'pre',
                opacity: s,
                transform: `translateY(${(1 - s) * 90}px)`,
              }}
            >
              {ch}
            </span>
          );
        })}
      </div>

      <div
        style={{
          position: 'absolute',
          top: 625,
          width: '100%',
          display: 'flex',
          justifyContent: 'center',
          gap: 26,
          fontFamily: en,
          fontWeight: 700,
          fontSize: 74,
          color: C.yellow,
        }}
      >
        {content.tagline.map((w, i) => {
          const s = spring({frame: f - 52 - i * 9, fps, config: {damping: 10, stiffness: 140}});
          return (
            <span key={w} style={{opacity: s, transform: `scale(${0.4 + 0.6 * s})`}}>
              {w}
            </span>
          );
        })}
      </div>

      <div
        style={{
          position: 'absolute',
          top: 740,
          width: '100%',
          textAlign: 'center',
          fontFamily: en,
          fontWeight: 600,
          fontSize: 40,
          color: C.mut,
          opacity: college,
        }}
      >
        {content.college}
      </div>

      <div style={{position: 'absolute', top: 830, width: '100%', display: 'flex', justifyContent: 'center'}}>
        <div
          style={{
            fontFamily: en,
            fontWeight: 800,
            fontSize: 54,
            color: C.green1,
            background: C.yellow,
            padding: '14px 50px',
            borderRadius: 80,
            opacity: pill,
            transform: `scale(${pill})`,
            boxShadow: '0 12px 40px rgba(0,0,0,0.35)',
          }}
        >
          {content.site}
        </div>
      </div>

      {PHOTOS.map((p, i) => {
        const s = spring({frame: f - p.delay, fps, config: {damping: 11, stiffness: 120}});
        const bob = Math.sin((f + i * 12) / 18) * 8;
        return (
          <div
            key={p.src}
            style={{
              position: 'absolute',
              left: p.x - p.d / 2,
              top: p.y - p.d / 2 + bob,
              width: p.d,
              height: p.d,
              borderRadius: '50%',
              overflow: 'hidden',
              border: '10px solid #fff',
              boxShadow: '0 20px 50px rgba(0,0,0,0.35)',
              transform: `scale(${s})`,
            }}
          >
            <Img
              src={staticFile(`places/${p.src}`)}
              style={{width: '100%', height: '100%', objectFit: 'cover'}}
            />
          </div>
        );
      })}
    </AbsoluteFill>
  );
};
