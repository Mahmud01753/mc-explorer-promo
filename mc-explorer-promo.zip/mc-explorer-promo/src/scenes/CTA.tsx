import React from 'react';
import {
  AbsoluteFill,
  Img,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {C} from '../theme';
import {bn, en} from '../fonts';
import {content} from '../content';
import {clamp} from '../utils';

export const CTA: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();

  const logo = spring({frame: f - 8, fps, config: {damping: 9, stiffness: 110}});
  const big = spring({frame: f - 16, fps, config: {damping: 9, stiffness: 120}});
  const sub = spring({frame: f - 28, fps, config: {damping: 14}});
  const pill = spring({frame: f - 36, fps, config: {damping: 10, stiffness: 120}});
  const ch = spring({frame: f - 84, fps, config: {damping: 12}});

  const pulse = 1 + Math.sin(f / 5) * 0.025;
  const press = interpolate(f, [78, 84, 92], [1, 0.93, 1], clamp);

  // cursor travelling to the button, then tapping
  const cx = interpolate(f, [50, 80], [900, 690], {...clamp});
  const cy = interpolate(f, [50, 80], [1420, 1075], {...clamp});
  const cursorOp = interpolate(f, [50, 58, 112, 124], [0, 1, 1, 0], clamp);
  const tapT = (f - 82) / 30;

  return (
    <AbsoluteFill style={{alignItems: 'center'}}>
      <Img
        src={staticFile('logo.png')}
        style={{
          position: 'absolute',
          top: 160,
          width: 290,
          height: 290,
          transform: `translateY(${Math.sin(f / 12) * 8}px) scale(${logo})`,
          filter: 'drop-shadow(0 0 40px rgba(255,210,63,0.6))',
        }}
      />

      <div
        style={{
          position: 'absolute',
          top: 470,
          fontFamily: bn,
          fontWeight: 800,
          fontSize: 200,
          color: C.yellow,
          opacity: big,
          transform: `scale(${0.4 + 0.6 * big})`,
          textShadow: '0 0 70px rgba(255,210,63,0.5)',
        }}
      >
        {content.cta.big}
      </div>

      <div
        style={{
          position: 'absolute',
          top: 740,
          fontFamily: bn,
          fontWeight: 800,
          fontSize: 66,
          color: '#fff',
          opacity: sub,
          transform: `translateY(${(1 - sub) * 40}px)`,
        }}
      >
        {content.cta.sub}
      </div>

      {/* URL button with ripples */}
      <div style={{position: 'absolute', top: 930, left: 100, width: 880, height: 170}}>
        {[0, 1].map((k) => {
          const t = ((f + k * 22) % 44) / 44;
          return (
            <div
              key={k}
              style={{
                position: 'absolute',
                inset: 0,
                borderRadius: 100,
                border: `6px solid ${C.yellow}`,
                opacity: (1 - t) * 0.7 * pill,
                transform: `scale(${1 + t * 0.22})`,
              }}
            />
          );
        })}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            borderRadius: 100,
            background: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontFamily: en,
            fontWeight: 800,
            fontSize: 84,
            color: C.green1,
            boxShadow: '0 0 80px rgba(255,210,63,0.55), 0 24px 60px rgba(0,0,0,0.4)',
            opacity: pill,
            transform: `scale(${pill * pulse * press})`,
          }}
        >
          {content.site}
        </div>
      </div>

      <div
        style={{
          position: 'absolute',
          top: 1190,
          fontFamily: bn,
          fontWeight: 800,
          fontSize: 50,
          color: C.green1,
          background: C.yellow,
          padding: '10px 46px',
          borderRadius: 70,
          opacity: ch,
          transform: `scale(${ch})`,
        }}
      >
        {content.cta.challenge}
      </div>

      <div
        style={{
          position: 'absolute',
          top: 1340,
          fontFamily: en,
          fontWeight: 600,
          fontSize: 38,
          color: C.mut,
          opacity: ch,
        }}
      >
        {content.college}
      </div>

      {/* tap ripple */}
      {tapT > 0 && tapT < 1 && (
        <div
          style={{
            position: 'absolute',
            left: 690 - 90 * tapT * 1.6,
            top: 1075 - 90 * tapT * 1.6,
            width: 180 * tapT * 1.6,
            height: 180 * tapT * 1.6,
            borderRadius: '50%',
            border: `6px solid ${C.green2}`,
            opacity: 1 - tapT,
          }}
        />
      )}

      {/* cursor */}
      <svg
        viewBox="0 0 40 40"
        width="110"
        height="110"
        style={{position: 'absolute', left: cx, top: cy, opacity: cursorOp, filter: 'drop-shadow(0 8px 14px rgba(0,0,0,0.5))'}}
      >
        <path d="M5 3 L5 28 L11 22 L16 33 L21 31 L16 20 L25 20 Z" fill="#fff" stroke={C.green1} strokeWidth="2" strokeLinejoin="round" />
      </svg>
    </AbsoluteFill>
  );
};
