import React from 'react';
import {
  AbsoluteFill,
  Easing,
  Img,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {C} from '../theme';
import {bn, en} from '../fonts';
import {content} from '../content';
import {clamp} from '../utils';

export const Hook: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();

  const zoom = interpolate(f, [10, 66], [6, 1], {
    ...clamp,
    easing: Easing.bezier(0.2, 0.7, 0.2, 1),
  });
  const blur = interpolate(f, [10, 62], [28, 0], clamp);
  const qMark = interpolate(f, [0, 10, 48, 66], [0, 1, 1, 0], clamp);
  const t1 = spring({frame: f - 6, fps, config: {damping: 16}});
  const t2 = spring({frame: f - 14, fps, config: {damping: 16}});
  const circ = spring({frame: f - 2, fps, config: {damping: 12, stiffness: 90}});
  const chip = spring({frame: f - 66, fps, config: {damping: 10, stiffness: 140}});
  const flash = interpolate(f, [64, 70, 90], [0, 0.55, 0], clamp);
  const cross = interpolate(f, [0, 10, 54, 68], [0, 0.8, 0.8, 0], clamp);
  const pulse = 1 + Math.sin(f / 4) * 0.05;

  return (
    <AbsoluteFill style={{alignItems: 'center'}}>
      <div style={{marginTop: 220, textAlign: 'center', fontFamily: bn}}>
        <div
          style={{
            fontSize: 96,
            fontWeight: 800,
            color: C.white,
            opacity: t1,
            transform: `translateY(${(1 - t1) * 60}px)`,
          }}
        >
          {content.hook.l1}
        </div>
        <div
          style={{
            fontSize: 96,
            fontWeight: 800,
            color: C.yellow,
            opacity: t2,
            transform: `translateY(${(1 - t2) * 60}px)`,
          }}
        >
          {content.hook.l2}
        </div>
      </div>

      <div
        style={{
          position: 'absolute',
          top: 620,
          left: 130,
          width: 820,
          height: 820,
          borderRadius: '50%',
          overflow: 'hidden',
          border: '14px solid #fff',
          boxShadow: `0 0 ${60 + flash * 200}px rgba(255,210,63,${0.35 + flash})`,
          transform: `scale(${circ})`,
        }}
      >
        <Img
          src={staticFile('places/chem.jpg')}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            transform: `scale(${zoom})`,
            filter: `blur(${blur}px)`,
          }}
        />
        <svg
          viewBox="0 0 820 820"
          style={{position: 'absolute', inset: 0, opacity: cross}}
        >
          <circle cx="410" cy="410" r="150" fill="none" stroke={C.yellow} strokeWidth="4" strokeDasharray="14 12" />
          <line x1="410" y1="170" x2="410" y2="280" stroke={C.yellow} strokeWidth="4" />
          <line x1="410" y1="540" x2="410" y2="650" stroke={C.yellow} strokeWidth="4" />
          <line x1="170" y1="410" x2="280" y2="410" stroke={C.yellow} strokeWidth="4" />
          <line x1="540" y1="410" x2="650" y2="410" stroke={C.yellow} strokeWidth="4" />
        </svg>
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontFamily: en,
            fontWeight: 800,
            fontSize: 380,
            color: '#fff',
            opacity: qMark * 0.9,
            transform: `scale(${pulse})`,
            textShadow: '0 10px 50px rgba(0,0,0,0.6)',
          }}
        >
          ?
        </div>
      </div>

      <div
        style={{
          position: 'absolute',
          top: 1500,
          fontFamily: bn,
          fontWeight: 800,
          fontSize: 80,
          color: C.green1,
          background: C.yellow,
          padding: '10px 54px',
          borderRadius: 100,
          boxShadow: '0 20px 60px rgba(0,0,0,0.35)',
          opacity: chip,
          transform: `scale(${chip})`,
        }}
      >
        {content.hook.answer}
      </div>
    </AbsoluteFill>
  );
};
