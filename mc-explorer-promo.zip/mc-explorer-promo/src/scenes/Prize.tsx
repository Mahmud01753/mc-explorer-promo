import React from 'react';
import {
  AbsoluteFill,
  interpolate,
  random,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {C, S} from '../theme';
import {bn} from '../fonts';
import {content} from '../content';
import {bnNum, clamp} from '../utils';

const GX = 540;
const GY = 1000;

const Confetti: React.FC<{start: number}> = ({start}) => {
  const f = useCurrentFrame();
  const t = (f - start) / 30;
  if (t < 0) return null;
  return (
    <>
      {new Array(70).fill(0).map((_, i) => {
        const a = random(`a${i}`) * Math.PI * 2;
        const sp = 500 + random(`s${i}`) * 900;
        const vx = Math.cos(a) * sp * 0.7;
        const vy = -Math.abs(Math.sin(a)) * sp - 300;
        const x = GX + vx * t;
        const y = GY - 80 + vy * t + 0.5 * 2600 * t * t;
        const rot = random(`r${i}`) * 360 + t * (200 + random(`q${i}`) * 500);
        const w = 14 + random(`w${i}`) * 14;
        const col = [C.yellow, '#ffffff', C.green3, '#ff8a3d'][i % 4];
        const op = interpolate(t, [1.6, 2.6], [1, 0], clamp);
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x,
              top: y,
              width: w,
              height: w * 0.5,
              background: col,
              opacity: op,
              borderRadius: 3,
              transform: `rotate(${rot}deg)`,
            }}
          />
        );
      })}
    </>
  );
};

export const Prize: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const out = interpolate(f, [S.prize.d - 10, S.prize.d], [1, 0], clamp);

  const l1 = spring({frame: f - 8, fps, config: {damping: 14}});
  const l2 = spring({frame: f - 16, fps, config: {damping: 11, stiffness: 120}});
  const l3 = spring({frame: f - 26, fps, config: {damping: 14}});
  const count = Math.round(
    interpolate(f, [18, 50], [0, content.prize.winners], clamp)
  );
  const gift = spring({frame: f - 14, fps, config: {damping: 9, stiffness: 100}});
  const open = spring({frame: f - 38, fps, config: {damping: 8, stiffness: 120}});
  const bounce = Math.sin(f / 5) * 6 * (1 - open);

  return (
    <AbsoluteFill style={{opacity: out}}>
      <div style={{position: 'absolute', top: 250, width: '100%', textAlign: 'center', fontFamily: bn}}>
        <div style={{fontSize: 56, fontWeight: 600, color: C.mut, opacity: l1, transform: `translateY(${(1 - l1) * 40}px)`}}>
          {content.prize.l1}
        </div>
        <div
          style={{
            fontSize: 160,
            fontWeight: 800,
            color: C.yellow,
            lineHeight: 1.15,
            opacity: l2,
            transform: `scale(${0.5 + 0.5 * l2})`,
            textShadow: '0 0 60px rgba(255,210,63,0.45)',
          }}
        >
          {bnNum(count)} {content.prize.l2suffix}
        </div>
        <div style={{fontSize: 74, fontWeight: 800, color: '#fff', opacity: l3, transform: `translateY(${(1 - l3) * 40}px)`}}>
          {content.prize.l3}
        </div>
      </div>

      {/* rotating light rays */}
      <div
        style={{
          position: 'absolute',
          left: GX - 520,
          top: GY - 520,
          width: 1040,
          height: 1040,
          borderRadius: '50%',
          background:
            'repeating-conic-gradient(from 0deg, rgba(255,210,63,0.30) 0deg 10deg, rgba(255,210,63,0) 10deg 24deg)',
          WebkitMaskImage: 'radial-gradient(circle, #000 20%, transparent 68%)',
          maskImage: 'radial-gradient(circle, #000 20%, transparent 68%)',
          transform: `rotate(${f * 1.2}deg) scale(${gift})`,
        }}
      />

      {/* gift box */}
      <div
        style={{
          position: 'absolute',
          left: GX - 220,
          top: GY - 240 + bounce,
          width: 440,
          height: 440,
          transform: `scale(${gift})`,
          filter: 'drop-shadow(0 30px 50px rgba(0,0,0,0.45))',
        }}
      >
        <svg viewBox="0 0 400 400" width="440" height="440">
          <rect x="60" y="180" width="280" height="200" rx="18" fill={C.yellow} />
          <rect x="180" y="180" width="40" height="200" fill={C.green2} />
          <g transform={`translate(0 ${-open * 90}) rotate(${open * -14} 200 150)`}>
            <rect x="40" y="120" width="320" height="80" rx="18" fill={C.yellow2} />
            <rect x="180" y="120" width="40" height="80" fill={C.green2} />
            <ellipse cx="160" cy="108" rx="48" ry="30" fill="none" stroke={C.green2} strokeWidth="18" transform="rotate(-20 160 108)" />
            <ellipse cx="240" cy="108" rx="48" ry="30" fill="none" stroke={C.green2} strokeWidth="18" transform="rotate(20 240 108)" />
          </g>
        </svg>
      </div>

      <Confetti start={40} />

      {/* five winner stars */}
      <div style={{position: 'absolute', top: 1330, width: '100%', display: 'flex', justifyContent: 'center', gap: 26}}>
        {new Array(content.prize.winners).fill(0).map((_, i) => {
          const s = spring({frame: f - 52 - i * 7, fps, config: {damping: 8, stiffness: 140}});
          return (
            <svg
              key={i}
              viewBox="0 0 100 100"
              width="120"
              height="120"
              style={{transform: `scale(${s}) rotate(${(1 - s) * -90}deg)`, filter: 'drop-shadow(0 0 18px rgba(255,210,63,0.7))'}}
            >
              <polygon points="50,5 61,38 96,38 68,59 79,92 50,72 21,92 32,59 4,38 39,38" fill={C.yellow} />
            </svg>
          );
        })}
      </div>

      {/* how to win chips */}
      <div style={{position: 'absolute', top: 1500, width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 16, fontFamily: bn}}>
        {content.prize.chips.map((c, i) => {
          const s = spring({frame: f - 74 - i * 9, fps, config: {damping: 12}});
          return (
            <React.Fragment key={c}>
              <div
                style={{
                  fontWeight: 800,
                  fontSize: 40,
                  color: C.green1,
                  background: '#fff',
                  padding: '12px 30px',
                  borderRadius: 60,
                  opacity: s,
                  transform: `scale(${s})`,
                  whiteSpace: 'nowrap',
                }}
              >
                {c}
              </div>
              {i < content.prize.chips.length - 1 && (
                <span style={{color: C.yellow, fontSize: 44, fontWeight: 800, opacity: s}}>›</span>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
