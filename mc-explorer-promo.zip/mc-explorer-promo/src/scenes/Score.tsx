import React from 'react';
import {
  AbsoluteFill,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {C, S} from '../theme';
import {bn, en} from '../fonts';
import {content} from '../content';
import {bnNum, clamp} from '../utils';

const RANK = [C.yellow, '#dfe7e2', '#e0975a', C.green3, C.green3];

export const Score: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const out = interpolate(f, [S.score.d - 10, S.score.d], [1, 0], clamp);

  const title = spring({frame: f - 8, fps, config: {damping: 14}});
  const ringIn = spring({frame: f - 12, fps, config: {damping: 12}});
  const p = spring({frame: f - 22, fps, durationInFrames: 60, config: {damping: 200}});
  const r = 190;
  const circ = 2 * Math.PI * r;
  const head = spring({frame: f - 70, fps, config: {damping: 14}});

  return (
    <AbsoluteFill style={{alignItems: 'center', opacity: out}}>
      <div
        style={{
          marginTop: 250,
          fontFamily: bn,
          fontWeight: 800,
          fontSize: 78,
          color: C.white,
          opacity: title,
          transform: `translateY(${(1 - title) * 50}px)`,
        }}
      >
        {content.scoreTitle}
      </div>

      <div style={{position: 'absolute', top: 360, transform: `scale(${ringIn})`}}>
        <svg width="460" height="460" viewBox="0 0 460 460">
          <circle cx="230" cy="230" r={r} fill="none" stroke="rgba(255,255,255,0.14)" strokeWidth="38" />
          <circle
            cx="230" cy="230" r={r} fill="none" stroke={C.yellow} strokeWidth="38" strokeLinecap="round"
            strokeDasharray={circ} strokeDashoffset={circ * (1 - p * 0.9)}
            transform="rotate(-90 230 230)"
            style={{filter: 'drop-shadow(0 0 18px rgba(255,210,63,0.7))'}}
          />
          <text x="215" y="285" textAnchor="middle" fontFamily={bn} fontWeight={800} fontSize="190" fill="#fff">
            {bnNum(Math.round(p * 9))}
          </text>
          <text x="330" y="285" textAnchor="middle" fontFamily={bn} fontWeight={600} fontSize="58" fill={C.mut}>
            /{bnNum(10)}
          </text>
        </svg>
      </div>

      <div
        style={{
          position: 'absolute',
          top: 860,
          fontFamily: bn,
          fontWeight: 800,
          fontSize: 56,
          color: C.yellow,
          opacity: head,
          transform: `translateY(${(1 - head) * 30}px)`,
        }}
      >
        {content.boardTitle}
      </div>

      {content.board.map((row, i) => {
        const s = spring({frame: f - 80 - i * 8, fps, config: {damping: 14}});
        const bar = spring({frame: f - 88 - i * 8, fps, durationInFrames: 40, config: {damping: 200}});
        return (
          <div
            key={row.name}
            style={{
              position: 'absolute',
              top: 950 + i * 114,
              left: 90,
              width: 900,
              height: 100,
              borderRadius: 50,
              background: 'rgba(255,255,255,0.10)',
              border: '2px solid rgba(255,255,255,0.18)',
              display: 'flex',
              alignItems: 'center',
              padding: '0 22px',
              boxSizing: 'border-box',
              gap: 20,
              opacity: s,
              transform: `translateX(${(1 - s) * -700}px)`,
            }}
          >
            <div
              style={{
                width: 64,
                height: 64,
                borderRadius: '50%',
                background: RANK[i],
                color: i < 3 ? C.green1 : '#fff',
                fontFamily: bn,
                fontWeight: 800,
                fontSize: 40,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
              }}
            >
              {bnNum(i + 1)}
            </div>
            <div style={{fontFamily: en, fontWeight: 700, fontSize: 34, color: '#fff', width: 230, flexShrink: 0}}>
              {row.name}
            </div>
            <div style={{flex: 1, height: 22, borderRadius: 11, background: 'rgba(255,255,255,0.12)', overflow: 'hidden'}}>
              <div
                style={{
                  width: `${(row.score / 10) * 100 * bar}%`,
                  height: '100%',
                  borderRadius: 11,
                  background: `linear-gradient(90deg, ${C.green3}, ${C.yellow})`,
                }}
              />
            </div>
            <div style={{fontFamily: bn, fontWeight: 800, fontSize: 44, color: C.yellow, width: 70, textAlign: 'right'}}>
              {bnNum(Math.round(row.score * bar))}
            </div>
          </div>
        );
      })}
    </AbsoluteFill>
  );
};
