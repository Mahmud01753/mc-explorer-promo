import React from 'react';
import {
  AbsoluteFill,
  Img,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {C, S} from '../theme';
import {bn} from '../fonts';
import {content} from '../content';
import {bnNum, clamp} from '../utils';

const Visual: React.FC<{i: number; start: number}> = ({i, start}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const lf = f - start;

  if (i === 0) {
    const p = (Math.max(lf, 0) % 75) / 75;
    const zoom = interpolate(p, [0, 0.75, 1], [3.6, 1, 1]);
    const blur = interpolate(p, [0, 0.75, 1], [10, 0, 0]);
    return (
      <div style={{width: 220, height: 220, borderRadius: '50%', overflow: 'hidden', border: '8px solid #fff', flexShrink: 0}}>
        <Img
          src={staticFile('places/gate1.jpg')}
          style={{width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${zoom})`, filter: `blur(${blur}px)`}}
        />
      </div>
    );
  }

  if (i === 1) {
    const p = spring({frame: lf - 10, fps, durationInFrames: 50, config: {damping: 200}});
    const r = 90;
    const circ = 2 * Math.PI * r;
    return (
      <svg width="220" height="220" viewBox="0 0 220 220" style={{flexShrink: 0}}>
        <circle cx="110" cy="110" r={r} fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="22" />
        <circle
          cx="110" cy="110" r={r} fill="none" stroke={C.yellow} strokeWidth="22" strokeLinecap="round"
          strokeDasharray={circ} strokeDashoffset={circ * (1 - p)}
          transform="rotate(-90 110 110)"
        />
        <text x="110" y="136" textAnchor="middle" fontFamily={bn} fontWeight={800} fontSize="84" fill="#fff">
          {bnNum(Math.round(p * 10))}
        </text>
      </svg>
    );
  }

  const ping = (lf % 45) / 45;
  const nodes = [
    [50, 110],
    [170, 45],
    [170, 175],
  ];
  return (
    <svg width="220" height="220" viewBox="0 0 220 220" style={{flexShrink: 0}}>
      <line x1="50" y1="110" x2="170" y2="45" stroke="#fff" strokeWidth="6" />
      <line x1="50" y1="110" x2="170" y2="175" stroke="#fff" strokeWidth="6" />
      <circle cx="50" cy="110" r={24 + ping * 40} fill="none" stroke={C.yellow} strokeWidth="5" opacity={1 - ping} />
      {nodes.map(([x, y], k) => (
        <circle key={k} cx={x} cy={y} r="26" fill={k === 0 ? C.yellow : '#fff'} />
      ))}
    </svg>
  );
};

export const Steps: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const title = spring({frame: f - 8, fps, config: {damping: 14}});
  const out = interpolate(f, [S.steps.d - 10, S.steps.d], [1, 0], clamp);

  return (
    <AbsoluteFill style={{alignItems: 'center', opacity: out}}>
      <div
        style={{
          marginTop: 270,
          fontFamily: bn,
          fontWeight: 800,
          fontSize: 100,
          color: C.white,
          opacity: title,
          transform: `translateY(${(1 - title) * 50}px)`,
        }}
      >
        {content.stepsTitle}
      </div>

      {content.steps.map((s, i) => {
        const start = 24 + i * 30;
        const p = spring({frame: f - start, fps, config: {damping: 14, stiffness: 100}});
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              top: 470 + i * 370,
              left: 90,
              width: 900,
              height: 320,
              borderRadius: 52,
              background: 'rgba(255,255,255,0.09)',
              border: '2px solid rgba(255,255,255,0.22)',
              display: 'flex',
              alignItems: 'center',
              gap: 36,
              padding: '0 44px',
              boxSizing: 'border-box',
              opacity: p,
              transform: `translateX(${(1 - p) * 1100}px)`,
              boxShadow: '0 24px 60px rgba(0,0,0,0.3)',
            }}
          >
            <div
              style={{
                position: 'absolute',
                top: -26,
                left: -14,
                width: 74,
                height: 74,
                borderRadius: '50%',
                background: C.yellow,
                color: C.green1,
                fontFamily: bn,
                fontWeight: 800,
                fontSize: 48,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 8px 24px rgba(0,0,0,0.35)',
              }}
            >
              {bnNum(i + 1)}
            </div>
            <Visual i={i} start={start} />
            <div style={{fontFamily: bn}}>
              <div style={{fontWeight: 800, fontSize: 54, color: '#fff', lineHeight: 1.2}}>{s.title}</div>
              <div style={{fontWeight: 600, fontSize: 36, color: C.mut, marginTop: 10, lineHeight: 1.3}}>{s.sub}</div>
            </div>
          </div>
        );
      })}
    </AbsoluteFill>
  );
};
