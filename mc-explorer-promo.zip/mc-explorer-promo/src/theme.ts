// Brand colors taken from the MC Explorer site (deep green + yellow)
export const C = {
  green0: '#06241a',
  green1: '#0b3d2a',
  green2: '#0f6b46',
  green3: '#1d8a5b',
  yellow: '#ffd23f',
  yellow2: '#ffb800',
  white: '#ffffff',
  mut: '#bfe3d0',
};

export const FPS = 30;
export const TOTAL = 900; // 30 seconds

// Scene timeline (frames @30fps)
export const S = {
  hook: {from: 0, d: 120}, //   0s - 4s
  brand: {from: 120, d: 150}, //   4s - 9s
  steps: {from: 270, d: 210}, //   9s - 16s
  score: {from: 480, d: 150}, //  16s - 21s
  prize: {from: 630, d: 135}, //  21s - 25.5s
  cta: {from: 765, d: 135}, //  25.5s - 30s
};

// Set to false to render without the voice-over
export const VOICE_ENABLED = true;

// Set to false to render without background music
export const MUSIC_ENABLED = true;
