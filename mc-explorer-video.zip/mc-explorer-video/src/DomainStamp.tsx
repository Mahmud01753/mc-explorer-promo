import React from "react";
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {SITE_LABEL} from "./theme";
import {FONT} from "./ui";

// পুরো ভিডিওতে ঝুলে থাকা ডোমেইন সিল: যখন যেখানে খালি জায়গা, সেখানে যায়, প্রতিবার নতুন রঙে
type Pos = React.CSSProperties;
const L = 135; // ফোন-সিনে বাম কলামের শুরু

const SPOTS: {from: number; to: number; pos: Pos}[] = [
  {from: 0, to: 100, pos: {top: 18, left: 0, right: 0, margin: "0 auto", width: "fit-content"}}, // হুক
  {from: 100, to: 190, pos: {bottom: 22, left: 0, right: 0, margin: "0 auto", width: "fit-content"}}, // ইন্ট্রো
  {from: 190, to: 290, pos: {top: 330, right: 18}}, // গ্যালারি: ডানে
  {from: 290, to: 390, pos: {top: 330, left: 18}}, // গ্যালারি: বামে
  {from: 390, to: 490, pos: {top: 330, right: 18}},
  {from: 490, to: 590, pos: {top: 330, left: 18}},
  {from: 590, to: 720, pos: {top: 22, left: L}}, // হোম
  {from: 720, to: 890, pos: {bottom: 22, left: L}}, // নিয়ম
  {from: 890, to: 1030, pos: {top: 22, left: L}}, // কুইজ
  {from: 1030, to: 1170, pos: {bottom: 22, left: L}}, // কার্ড
  {from: 1170, to: 1310, pos: {top: 22, left: L}}, // লিডারবোর্ড
  {from: 1310, to: 1420, pos: {bottom: 24, right: 24}}, // চ্যাট ও সার্ভে
  {from: 1420, to: 1570, pos: {top: 10, left: L}}, // পুরস্কার
  {from: 1570, to: 1660, pos: {top: 24, right: 24}}, // ট্রাস্ট
  {from: 1660, to: 1800, pos: {top: 24, left: 24}}, // CTA
];

// প্রতিবার আলাদা রঙ: [ব্যাকগ্রাউন্ড, লেখা, বর্ডার]
const COLORS: [string, string, string][] = [
  ["linear-gradient(90deg,#f43f5e,#e11d48)", "#ffffff", "#ffe4e9"],
  ["linear-gradient(90deg,#fcd34d,#f59e0b)", "#3b2300", "#fff3c4"],
  ["linear-gradient(90deg,#34d399,#10b981)", "#032b1f", "#d1fae5"],
  ["linear-gradient(90deg,#38bdf8,#2563eb)", "#ffffff", "#dbeafe"],
  ["linear-gradient(90deg,#a78bfa,#7c3aed)", "#ffffff", "#ede9fe"],
  ["linear-gradient(90deg,#fb923c,#ea580c)", "#ffffff", "#ffedd5"],
  ["linear-gradient(90deg,#a3e635,#65a30d)", "#1a2e05", "#ecfccb"],
  ["linear-gradient(90deg,#22d3ee,#0891b2)", "#032a33", "#cffafe"],
];

export const DomainStamp: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const idx = Math.max(0, SPOTS.findIndex((s) => f >= s.from && f < s.to));
  const spot = SPOTS[idx];
  const local = f - spot.from;
  const left = spot.to - f;
  const [bg, fg, bd] = COLORS[idx % COLORS.length];

  // সিল মারার মতো: বড় হয়ে এসে বসে যায়
  const pop = spring({frame: local, fps, config: {damping: 12, stiffness: 160, mass: 0.6}});
  const scale = interpolate(pop, [0, 1], [1.5, 1]);
  const opacity = interpolate(local, [0, 6], [0, 1], {extrapolateRight: "clamp"}) *
    interpolate(left, [0, 5], [0, 1], {extrapolateRight: "clamp"});
  const rot = (idx % 2 === 0 ? -3 : 3) * (1 + (1 - pop) * 1.5);

  return (
    <AbsoluteFill style={{pointerEvents: "none", fontFamily: FONT}}>
      <div style={{position: "absolute", ...spot.pos}}>
        <div
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
            padding: "7px 18px",
            borderRadius: 14,
            background: bg,
            color: fg,
            fontSize: 24,
            fontWeight: 700,
            letterSpacing: 0.4,
            border: `2px dashed ${bd}`,
            outline: `3px solid ${fg}22`,
            outlineOffset: 2,
            boxShadow: "0 8px 22px rgba(0,0,0,.4)",
            opacity,
            transform: `rotate(${rot}deg) scale(${scale})`,
          }}
        >
          <span>🌐</span>
          <span>{SITE_LABEL}</span>
        </div>
      </div>
    </AbsoluteFill>
  );
};
