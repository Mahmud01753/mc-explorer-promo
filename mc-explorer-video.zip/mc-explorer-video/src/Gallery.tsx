import React from "react";
import {AbsoluteFill, Easing, Img, Sequence, interpolate, staticFile, useCurrentFrame} from "remotion";
import {C} from "./theme";
import {GradText, Rise, Scene} from "./ui";
import {HEROES, OVERLAP, PHOTOS, THUMBS} from "./photos";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const STAGE_W = 720;
const STAGE_H = 400;
const src = (id: number) => staticFile(`photos/p${String(id).padStart(2, "0")}.jpg`);

// একটা বড় ছবি: জুম-আউট হয়ে আসে, পরেরটা এলে ছোট হয়ে মিলিয়ে যায়
const Hero: React.FC<{id: number; dur: number}> = ({id, dur}) => {
  const f = useCurrentFrame();
  const p = PHOTOS[id];
  const enter = interpolate(f, [0, OVERLAP], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  const exit = interpolate(f, [dur, dur + OVERLAP], [0, 1], clamp);
  const zoom = interpolate(f, [0, dur + OVERLAP], [1.28, 1.0], clamp);
  const wide = p.w / p.h >= 1.5;
  return (
    <div
      style={{
        position: "absolute",
        left: (1280 - STAGE_W) / 2,
        top: 104,
        width: STAGE_W,
        opacity: enter * (1 - exit),
        transform: `translateY(${(1 - enter) * 30 - exit * 26}px) scale(${1 - exit * 0.15})`,
        filter: `blur(${exit * 6}px) brightness(${1 - exit * 0.4})`,
      }}
    >
      <div
        style={{
          position: "relative",
          width: STAGE_W,
          height: STAGE_H,
          borderRadius: 24,
          overflow: "hidden",
          background: "#0a1a12",
          boxShadow: `0 30px 80px rgba(0,0,0,.55), 0 0 0 2px ${C.border}`,
        }}
      >
        {!wide && (
          <Img
            src={src(id)}
            style={{
              position: "absolute",
              inset: 0,
              width: "100%",
              height: "100%",
              objectFit: "cover",
              filter: "blur(22px) brightness(.55)",
              transform: "scale(1.2)",
            }}
          />
        )}
        <Img
          src={src(id)}
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
            objectFit: wide ? "cover" : "contain",
            transform: `scale(${zoom})`,
          }}
        />
      </div>
      <div style={{textAlign: "center", marginTop: 14}}>
        <span
          style={{
            display: "inline-block",
            padding: "8px 22px",
            borderRadius: 999,
            background: C.card,
            border: `1px solid ${C.border}`,
            color: C.text,
            fontSize: 26,
            fontWeight: 700,
          }}
        >
          📍 {p.caption}
        </span>
      </div>
    </div>
  );
};

// নিচের ছোট ছবির চলমান সারি
const Strip: React.FC = () => {
  const f = useCurrentFrame();
  const item = 168;
  const rowW = THUMBS.length * item;
  const x = -((f * 1.8) % rowW);
  const row = [...THUMBS, ...THUMBS, ...THUMBS];
  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        top: 604,
        height: 88,
        overflow: "hidden",
        WebkitMaskImage: "linear-gradient(90deg, transparent, black 10%, black 90%, transparent)",
        maskImage: "linear-gradient(90deg, transparent, black 10%, black 90%, transparent)",
      }}
    >
      <div style={{display: "flex", gap: 12, transform: `translateX(${x}px)`, width: row.length * item}}>
        {row.map((id, i) => (
          <Img
            key={i}
            src={src(id)}
            style={{
              width: item - 12,
              height: 88,
              objectFit: "cover",
              borderRadius: 14,
              opacity: 0.85,
              border: `1px solid ${C.border}`,
            }}
          />
        ))}
      </div>
    </div>
  );
};

export const GalleryScene: React.FC = () => {
  let t = 0;
  const seqs = HEROES.map((h) => {
    const from = t;
    t += h.dur;
    return {...h, from};
  });
  return (
    <Scene>
      <AbsoluteFill>
        <div style={{position: "absolute", top: 26, left: 0, right: 0, textAlign: "center"}}>
          <Rise>
            <div style={{fontSize: 46, fontWeight: 700, color: C.text}}>
              এই জায়গাগুলো <GradText>চেনো?</GradText>
            </div>
          </Rise>
        </div>
        {seqs.map((s) => (
          <Sequence key={s.id + "-" + s.from} from={s.from} durationInFrames={s.dur + OVERLAP}>
            <Hero id={s.id} dur={s.dur} />
          </Sequence>
        ))}
        <Strip />
      </AbsoluteFill>
    </Scene>
  );
};
