import React from "react";
import {
  AbsoluteFill,
  Audio,
  Easing,
  Img,
  Sequence,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import {C} from "./theme";
import {GradText, Rise, Scene} from "./ui";
import {CENTER, HEROES, HeroStyle, MOSAIC, MOSAIC_START, OVERLAP, PHOTOS} from "./photos";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const STAGE_W = 720;
const STAGE_H = 400;
const src = (id: number) => staticFile(`photos/p${String(id).padStart(2, "0")}.jpg`);

// ছবি আসা-যাওয়ার ধরন। e = আসার সময় (১ থেকে ০), x = যাওয়ার সময় (০ থেকে ১)
const styleTransform = (style: HeroStyle, e: number, x: number): string => {
  switch (style) {
    case "slideL":
      return `translateX(${e * 520 - x * 520}px)`;
    case "slideR":
      return `translateX(${-e * 520 + x * 520}px)`;
    case "slideU":
      return `translateY(${e * 320 - x * 320}px)`;
    case "slideD":
      return `translateY(${-e * 320 + x * 320}px)`;
    case "zoomIn":
      return `scale(${1 - e * 0.55 + x * 0.45})`;
    case "zoomOut":
      return `scale(${1 + e * 0.6 - x * 0.4})`;
    case "rotate":
      return `rotate(${-e * 14 + x * 14}deg) scale(${1 - e * 0.25 - x * 0.2})`;
    case "flip":
      return `perspective(1000px) rotateY(${e * 85 - x * 85}deg)`;
  }
};

// একটা বা দুইটা ছবি: ফ্রেম পুরো ভরে থাকে, প্রতিবার আলাদা স্টাইলে আসে-যায়
const GAP = 16;
const Hero: React.FC<{ids: number[]; dur: number; style: HeroStyle}> = ({ids, dur, style}) => {
  const f = useCurrentFrame();
  const enter = interpolate(f, [0, OVERLAP], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  const exit = interpolate(f, [dur, dur + OVERLAP], [0, 1], clamp);
  const kbIn = style === "zoomIn";
  const zoom = kbIn
    ? interpolate(f, [0, dur + OVERLAP], [1.0, 1.22], clamp)
    : interpolate(f, [0, dur + OVERLAP], [1.28, 1.0], clamp);
  const single = ids.length === 1;
  const pw = single ? STAGE_W : (STAGE_W - GAP) / 2;
  return (
    <div
      style={{
        position: "absolute",
        left: (1280 - STAGE_W) / 2,
        top: 104,
        width: STAGE_W,
        opacity: enter * (1 - exit),
        transform: styleTransform(style, 1 - enter, exit),
        filter: `brightness(${1 - exit * 0.4})`,
      }}
    >
      <div style={{display: "flex", gap: GAP, width: STAGE_W, height: STAGE_H}}>
        {ids.map((id) => (
          <div
            key={id}
            style={{
              position: "relative",
              width: pw,
              height: STAGE_H,
              borderRadius: 24,
              overflow: "hidden",
              background: "#0a1a12",
              boxShadow: `0 30px 80px rgba(0,0,0,.55), 0 0 0 2px ${C.border}`,
            }}
          >
            <Img
              src={src(id)}
              style={{
                position: "absolute",
                inset: 0,
                width: "100%",
                height: "100%",
                objectFit: "cover",
                transform: `scale(${zoom})`,
              }}
            />
          </div>
        ))}
      </div>
      <div style={{display: "flex", gap: GAP, width: STAGE_W, marginTop: 14}}>
        {ids.map((id) => (
          <div key={id} style={{width: pw, textAlign: "center"}}>
            <span
              style={{
                display: "inline-block",
                padding: "8px 22px",
                borderRadius: 999,
                background: C.card,
                border: `1px solid ${C.border}`,
                color: C.text,
                fontSize: single ? 26 : 19,
                fontWeight: 700,
                whiteSpace: "nowrap",
              }}
            >
              📍 {PHOTOS[id].caption}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

/* ---------------- শেষ ধাপ: সব ছবি গ্যালারি হয়ে বসে ---------------- */

const CX = 270;
const CW = 740;
const CY = 216;
const CH = 372;
const TILE = 88; // ওপর-নিচের সারির উচ্চতা
const COLW = 200; // পাশের কলামের প্রস্থ
const COLH = 118;

const settle = (f: number, fps: number, delay: number) =>
  spring({frame: f - delay, fps, config: {damping: 200}});

// একটা ছোট টাইল: আলাদা আলাদা ভাবে জুম ইন-আউট হয়
const Tile: React.FC<{id: number; w: number; h: number; i: number; f: number}> = ({id, w, h, i, f}) => {
  const mode = i % 3;
  const inner = 1 + 0.09 + 0.09 * Math.sin(f / 14 + i * 0.9); // ভেতরের ছবি জুম ইন-আউট
  const outer = mode === 1 ? 1 + 0.045 * Math.sin(f / 16 + i) : 1; // পুরো টাইল শ্বাস নেয়
  const panX = mode === 2 ? Math.sin(f / 30 + i) * 6 : 0;
  return (
    <div
      style={{
        width: w,
        height: h,
        flexShrink: 0,
        borderRadius: 14,
        overflow: "hidden",
        border: `1px solid ${C.border}`,
        boxShadow: "0 8px 22px rgba(0,0,0,.35)",
        transform: `scale(${outer})`,
      }}
    >
      <Img
        src={src(id)}
        style={{
          width: "100%",
          height: "100%",
          objectFit: "cover",
          transform: `translateX(${panX}px) scale(${inner})`,
        }}
      />
    </div>
  );
};

// অনুভূমিক সারি (ওপর/নিচ): ডানে-বামে স্লাইড
const HRow: React.FC<{ids: number[]; top: number; dir: 1 | -1; f: number; fps: number; delay: number; from: number}> = ({
  ids,
  top,
  dir,
  f,
  fps,
  delay,
  from,
}) => {
  const item = 160;
  const gap = 10;
  const step = item + gap;
  const rowW = ids.length * step;
  const sp = settle(f, fps, delay);
  const t = (f * 1.7) % rowW;
  const x = dir === 1 ? -rowW + t : -t;
  const row = [...ids, ...ids, ...ids];
  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        top,
        height: TILE,
        overflow: "hidden",
        opacity: sp,
        transform: `translateY(${(1 - sp) * from}px)`,
        WebkitMaskImage: "linear-gradient(90deg, transparent, black 8%, black 92%, transparent)",
        maskImage: "linear-gradient(90deg, transparent, black 8%, black 92%, transparent)",
      }}
    >
      <div style={{display: "flex", gap, transform: `translateX(${x}px)`, width: row.length * step}}>
        {row.map((id, i) => (
          <Tile key={i} id={id} w={item} h={TILE} i={i} f={f} />
        ))}
      </div>
    </div>
  );
};

// উল্লম্ব কলাম (বাম/ডান): ওপরে-নিচে স্লাইড
const VCol: React.FC<{ids: number[]; left: number; dir: 1 | -1; f: number; fps: number; delay: number; from: number}> = ({
  ids,
  left,
  dir,
  f,
  fps,
  delay,
  from,
}) => {
  const gap = 10;
  const step = COLH + gap;
  const colH = ids.length * step;
  const sp = settle(f, fps, delay);
  const t = (f * 1.4) % colH;
  const y = dir === 1 ? -colH + t : -t;
  const col = [...ids, ...ids, ...ids];
  return (
    <div
      style={{
        position: "absolute",
        left,
        top: CY,
        width: COLW,
        height: CH,
        overflow: "hidden",
        opacity: sp,
        transform: `translateX(${(1 - sp) * from}px)`,
        WebkitMaskImage: "linear-gradient(180deg, transparent, black 10%, black 90%, transparent)",
        maskImage: "linear-gradient(180deg, transparent, black 10%, black 90%, transparent)",
      }}
    >
      <div style={{display: "flex", flexDirection: "column", gap, transform: `translateY(${y}px)`}}>
        {col.map((id, i) => (
          <Tile key={i} id={id} w={COLW} h={COLH} i={i + 1} f={f} />
        ))}
      </div>
    </div>
  );
};

// মাঝখানের বড় ছবি: একটার পর একটা, আলাদা স্টাইলে আসে; জুম ইন/আউট চলতেই থাকে
const CenterPhoto: React.FC<{id: number; style: HeroStyle; idx: number; dur: number}> = ({id, style, idx, dur}) => {
  const f = useCurrentFrame();
  const enter = interpolate(f, [0, 14], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  const kb = idx % 2 === 0
    ? interpolate(f, [0, dur], [1.0, 1.2], clamp) // জুম ইন
    : interpolate(f, [0, dur], [1.2, 1.0], clamp); // জুম আউট
  return (
    <div
      style={{
        position: "absolute",
        left: CX,
        top: CY,
        width: CW,
        height: CH,
        opacity: enter,
        transform: styleTransform(style, 1 - enter, 0),
        borderRadius: 22,
        overflow: "hidden",
        background: "#0a1a12",
        boxShadow: `0 30px 80px rgba(0,0,0,.6), 0 0 0 3px ${C.gold}, 0 0 70px ${C.gold}33`,
      }}
    >
      <Img
        src={src(id)}
        style={{
          position: "absolute",
          inset: 0,
          width: "100%",
          height: "100%",
          objectFit: "cover",
          transform: `scale(${kb})`,
        }}
      />
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          bottom: 0,
          height: 90,
          background: "linear-gradient(to top, rgba(0,0,0,.65), transparent)",
        }}
      />
      <div style={{position: "absolute", left: 0, right: 0, bottom: 14, textAlign: "center"}}>
        <span
          style={{
            display: "inline-block",
            padding: "7px 20px",
            borderRadius: 999,
            background: "rgba(3,18,11,.7)",
            border: `1px solid ${C.border}`,
            color: C.text,
            fontSize: 24,
            fontWeight: 700,
          }}
        >
          📍 {PHOTOS[id].caption}
        </span>
      </div>
    </div>
  );
};

const Mosaic: React.FC = () => {
  const f = useCurrentFrame(); // মোজাইক শুরুর পর থেকে গোনা
  const {fps, durationInFrames} = useVideoConfig();
  const pop = settle(f, fps, 0);
  return (
    <AbsoluteFill>
      {/* মাঝখান: গ্যালারির ফ্রেম */}
      <div
        style={{
          position: "absolute",
          left: CX,
          top: CY,
          width: CW,
          height: CH,
          transform: `scale(${0.7 + 0.3 * pop})`,
          opacity: pop,
        }}
      >
        <div style={{position: "relative", width: CW, height: CH}}>
          {CENTER.map((c, k) => {
            const next = CENTER[k + 1];
            const dur = (next ? next.start : durationInFrames) - c.start + 14;
            return (
              <Sequence key={c.id} from={c.start} durationInFrames={Math.max(dur, 20)} layout="none">
                <div style={{position: "absolute", inset: 0, left: -CX, top: -CY}}>
                  <CenterPhoto id={c.id} style={k === 0 ? "zoomOut" : c.style} idx={k} dur={dur} />
                </div>
              </Sequence>
            );
          })}
        </div>
      </div>
      <HRow ids={MOSAIC.top} top={104} dir={-1} f={f} fps={fps} delay={4} from={-120} />
      <HRow ids={MOSAIC.bottom} top={608} dir={1} f={f} fps={fps} delay={8} from={120} />
      <VCol ids={MOSAIC.left} left={36} dir={-1} f={f} fps={fps} delay={12} from={-260} />
      <VCol ids={MOSAIC.right} left={1044} dir={1} f={f} fps={fps} delay={16} from={260} />
    </AbsoluteFill>
  );
};

export const GalleryScene: React.FC = () => {
  let t = 0;
  const seqs = HEROES.map((h) => {
    const from = t;
    t += h.dur;
    return {...h, from};
  });
  const {durationInFrames} = useVideoConfig();
  return (
    <Scene>
      <AbsoluteFill>
        <div style={{position: "absolute", top: 26, left: 0, right: 0, textAlign: "center"}}>
          <Rise>
            <div style={{fontSize: 46, fontWeight: 700, color: C.text}}>
              এই জায়গাগুলো <GradText>চেনো?</GradText>
            </div>
          </Rise>
        </div>
        {seqs.map((s) => (
          <Sequence key={s.ids.join("-") + "-" + s.from} from={s.from} durationInFrames={s.dur + OVERLAP}>
            <Hero ids={s.ids} dur={s.dur} style={s.style} />
          </Sequence>
        ))}
        <Sequence from={MOSAIC_START} durationInFrames={durationInFrames - MOSAIC_START}>
          <Mosaic />
          <Audio src={staticFile("audio/whoosh.wav")} volume={0.18} />
        </Sequence>
      </AbsoluteFill>
    </Scene>
  );
};
