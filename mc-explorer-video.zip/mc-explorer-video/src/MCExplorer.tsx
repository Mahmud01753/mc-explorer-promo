import React from "react";
import {AbsoluteFill, Audio, Series, staticFile} from "remotion";
import {DURATIONS as D} from "./theme";
import {Background} from "./ui";
import {GalleryScene} from "./Gallery";
import {
  BoardScene,
  CtaScene,
  HomeScene,
  HookScene,
  IntroScene,
  MoreScene,
  PrizeScene,
  QuizScene,
  ResultScene,
  RulesScene,
  TrustScene,
} from "./scenes";

export const MCExplorer: React.FC = () => (
  <AbsoluteFill>
    <Background />
    <Audio src={staticFile("audio/mix.mp3")} />
    <Series>
      <Series.Sequence durationInFrames={D.hook}><HookScene /></Series.Sequence>
      <Series.Sequence durationInFrames={D.intro}><IntroScene /></Series.Sequence>
      <Series.Sequence durationInFrames={D.gallery}><GalleryScene /></Series.Sequence>
      <Series.Sequence durationInFrames={D.home}><HomeScene /></Series.Sequence>
      <Series.Sequence durationInFrames={D.rules}><RulesScene /></Series.Sequence>
      <Series.Sequence durationInFrames={D.quiz}><QuizScene /></Series.Sequence>
      <Series.Sequence durationInFrames={D.result}><ResultScene /></Series.Sequence>
      <Series.Sequence durationInFrames={D.board}><BoardScene /></Series.Sequence>
      <Series.Sequence durationInFrames={D.more}><MoreScene /></Series.Sequence>
      <Series.Sequence durationInFrames={D.prize}><PrizeScene /></Series.Sequence>
      <Series.Sequence durationInFrames={D.trust}><TrustScene /></Series.Sequence>
      <Series.Sequence durationInFrames={D.cta}><CtaScene /></Series.Sequence>
    </Series>
  </AbsoluteFill>
);
