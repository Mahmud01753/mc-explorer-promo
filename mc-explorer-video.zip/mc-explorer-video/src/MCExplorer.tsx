import React from "react";
import {AbsoluteFill, Audio, Series, staticFile, useCurrentFrame} from "remotion";
import {DURATIONS as D, PRIZE_START, STAMP_AT} from "./theme";
import {Background, LogoBug} from "./ui";
import {DomainStamp} from "./DomainStamp";
import {GalleryScene} from "./Gallery";
import {
  BoardScene,
  CtaScene,
  HomeScene,
  HookScene,
  IntroScene,
  MoreScene,
  PrizeScene,
  QuizScene,
  ResultScene,
  RulesScene,
  TrustScene,
} from "./scenes";

// কার্ড সীল মারার মুহূর্তে পুরো স্ক্রিনে হালকা ঝাঁকুনি
const useShake = () => {
  const f = useCurrentFrame();
  let dx = 0, dy = 0, rot = 0, amp = 0;
  for (const a of STAMP_AT) {
    const d = f - (PRIZE_START + a);
    if (d >= 0 && d < 18) {
      const k = 8 * Math.exp(-d / 5);
      dx += Math.sin(d * 2.4) * k;
      dy += Math.cos(d * 3.1) * k * 0.7;
      rot += Math.sin(d * 2.0) * k * 0.04;
      amp += k;
    }
  }
  return `translate(${dx}px, ${dy}px) rotate(${rot}deg) scale(${1 + Math.min(amp, 8) * 0.004})`;
};

export const MCExplorer: React.FC = () => {
  const shake = useShake();
  return (
    <AbsoluteFill>
      <Audio src={staticFile("audio/mix.mp3")} />
      <AbsoluteFill style={{transform: shake}}>
        <Background />
        <Series>
          <Series.Sequence durationInFrames={D.hook}><HookScene /></Series.Sequence>
          <Series.Sequence durationInFrames={D.intro}><IntroScene /></Series.Sequence>
          <Series.Sequence durationInFrames={D.gallery}><GalleryScene /></Series.Sequence>
          <Series.Sequence durationInFrames={D.home}><HomeScene /></Series.Sequence>
          <Series.Sequence durationInFrames={D.rules}><RulesScene /></Series.Sequence>
          <Series.Sequence durationInFrames={D.quiz}><QuizScene /></Series.Sequence>
          <Series.Sequence durationInFrames={D.result}><ResultScene /></Series.Sequence>
          <Series.Sequence durationInFrames={D.board}><BoardScene /></Series.Sequence>
          <Series.Sequence durationInFrames={D.more}><MoreScene /></Series.Sequence>
          <Series.Sequence durationInFrames={D.prize}><PrizeScene /></Series.Sequence>
          <Series.Sequence durationInFrames={D.trust}><TrustScene /></Series.Sequence>
          <Series.Sequence durationInFrames={D.cta}><CtaScene /></Series.Sequence>
        </Series>
        <LogoBug />
        <DomainStamp />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
