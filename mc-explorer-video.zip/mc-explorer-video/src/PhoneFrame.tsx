import React from "react";
import {Easing, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from "remotion";
import {C} from "./theme";

const SCREEN_W = 340;
const SCREEN_H = Math.round(SCREEN_W * (1839 / 1080)); // স্ক্রিনশটের অনুপাত
const BEZEL = 10;
export const PHONE_W = SCREEN_W + BEZEL * 2;
export const PHONE_H = SCREEN_H + BEZEL * 2;

// আসল সাইটের স্ক্রিনশট ফোনের ভেতরে (public/shots/<name>.jpg)
export type TapSpec = {x: number; y: number; at: number}; // x,y = স্ক্রিনের ভগ্নাংশ (0–1)

const clampOpt = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

// আঙুলের ট্যাপ: নিচ থেকে এসে বাটনে চাপ + রিপল
const Tap: React.FC<TapSpec> = ({x, y, at}) => {
  const f = useCurrentFrame();
  const mv = interpolate(f, [at, at + 18], [0, 1], {...clampOpt, easing: Easing.out(Easing.cubic)});
  const hit = f - (at + 18);
  const rip = interpolate(hit, [0, 16], [0, 1], clampOpt);
  const press = hit >= 0 && hit < 6 ? 0.8 : 1;
  const show = interpolate(f, [at - 4, at], [0, 1], clampOpt) * (1 - interpolate(hit, [14, 26], [0, 1], clampOpt));
  const cx = x + 0.16 * (1 - mv);
  const cy = y + 0.2 * (1 - mv);
  return (
    <>
      {hit >= 0 && (
        <div
          style={{
            position: "absolute",
            left: `${x * 100}%`,
            top: `${y * 100}%`,
            width: 76,
            height: 76,
            margin: -38,
            borderRadius: "50%",
            border: `4px solid ${C.gold}`,
            transform: `scale(${0.3 + rip * 1.3})`,
            opacity: 1 - rip,
          }}
        />
      )}
      <div
        style={{
          position: "absolute",
          left: `${cx * 100}%`,
          top: `${cy * 100}%`,
          width: 40,
          height: 40,
          margin: -20,
          borderRadius: "50%",
          background: "rgba(255,255,255,.55)",
          border: "3px solid #fff",
          boxShadow: "0 6px 16px rgba(0,0,0,.35)",
          transform: `scale(${press})`,
          opacity: show,
        }}
      />
    </>
  );
};

// ক্যামেরা জুম: স্ক্রিনের কোন বিন্দুর দিকে (x, y = ভগ্নাংশ) কখন কতটা জুম
export type CamSpec = {x: number; y: number; frames: number[]; values: number[]};

export const PhoneFrame: React.FC<{
  shot: string;
  tilt?: number;
  tap?: TapSpec;
  overlay?: React.ReactNode; // স্ক্রিনশটের ওপরে বসানো অ্যানিমেটেড অংশ (যেমন টাইপ করা নাম)
  cam?: CamSpec;
}> = ({shot, tilt = 0, tap, overlay, cam}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f, fps, config: {damping: 200}});
  const float = Math.sin(f / 25) * 6;
  // হালকা ধীর জুম
  const zoom = interpolate(f, [0, 150], [1, 1.05], {extrapolateRight: "clamp"});
  const camScale = cam
    ? interpolate(f, cam.frames, cam.values, {...clampOpt, easing: Easing.inOut(Easing.cubic)})
    : 1;
  const ox = cam ? BEZEL + cam.x * SCREEN_W : PHONE_W / 2;
  const oy = cam ? BEZEL + cam.y * SCREEN_H : PHONE_H / 2;
  return (
    <div
      style={{
        width: PHONE_W,
        height: PHONE_H,
        flexShrink: 0,
        position: "relative",
        zIndex: camScale > 1 ? 5 : 0,
        transform: `scale(${camScale})`,
        transformOrigin: `${ox}px ${oy}px`,
      }}
    >
      <div
        style={{
          width: PHONE_W,
          height: PHONE_H,
          borderRadius: 44,
          padding: BEZEL,
          boxSizing: "border-box",
          background: "#0a0e0c",
          boxShadow: `0 40px 90px rgba(0,0,0,.6), 0 0 0 2px #26302b, 0 0 90px ${C.accent}33`,
          transform: `translateY(${(1 - s) * 70 + float}px) rotate(${tilt}deg)`,
          opacity: s,
          position: "relative",
        }}
      >
        <div style={{width: "100%", height: "100%", borderRadius: 34, overflow: "hidden", background: "#fff", position: "relative"}}>
          <div style={{position: "absolute", inset: 0, transform: `scale(${zoom})`, transformOrigin: "50% 30%"}}>
            <Img
              src={staticFile(`shots/${shot}.jpg`)}
              style={{
                width: "100%",
                height: "100%",
                objectFit: "cover",
                objectPosition: "top",
              }}
            />
            {overlay}
          </div>
          {tap && <Tap {...tap} />}
        </div>
        <div
          style={{
            position: "absolute",
            top: 16,
            left: "50%",
            width: 70,
            height: 6,
            marginLeft: -35,
            borderRadius: 99,
            background: "rgba(0,0,0,.45)",
          }}
        />
      </div>
    </div>
  );
};
