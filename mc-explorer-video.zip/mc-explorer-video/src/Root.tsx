import React from "react";
import {Composition} from "remotion";
import {MCExplorer} from "./MCExplorer";
import {FPS, TOTAL} from "./theme";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="MCExplorer"
    component={MCExplorer}
    durationInFrames={TOTAL}
    fps={FPS}
    width={1280}
    height={720}
  />
);
