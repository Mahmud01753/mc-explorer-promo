// ছবি ও ক্যাপশন: এখানে বদলানো যায়। id = public/photos/pNN.jpg
export const PHOTOS: Record<number, {w: number; h: number; caption: string}> = {
  1: {w: 494, h: 620, caption: "আকাশ থেকে পুকুর ও সিঁড়ি"},
  2: {w: 640, h: 480, caption: "পুকুরপাড়ের সিঁড়ি"},
  3: {w: 480, h: 639, caption: "সিঁড়ি ও ১০ তলা ভবন"},
  4: {w: 706, h: 434, caption: "একাডেমিক ভবন"},
  5: {w: 481, h: 637, caption: "১০ তলা একাডেমিক ভবন"},
  6: {w: 1400, h: 1050, caption: "ক্যাম্পাস মানচিত্র"},
  7: {w: 588, h: 330, caption: "রাষ্ট্রবিজ্ঞান ভবন"},
  8: {w: 415, h: 739, caption: "কলা ভবন"},
  9: {w: 1400, h: 700, caption: "সাইফুর রহমান একাডেমিক ভবন"},
  10: {w: 728, h: 409, caption: "কলেজ গেইট"},
  11: {w: 1400, h: 934, caption: "রসায়ন বিভাগ"},
  12: {w: 480, h: 640, caption: "শহীদ মিনার"},
  13: {w: 415, h: 739, caption: "আকাশ থেকে ক্যাম্পাস"},
  14: {w: 484, h: 633, caption: "প্রশাসনিক ভবন"},
  15: {w: 554, h: 554, caption: "কলেজ গেইট"},
  16: {w: 415, h: 739, caption: "পুকুর ও সিঁড়ি"},
  17: {w: 495, h: 619, caption: "পুকুরপাড় ও ১০ তলা ভবন"},
  18: {w: 588, h: 330, caption: "পুরোনো ভবন"},
  19: {w: 857, h: 482, caption: "টিনশেড ভবন"},
  20: {w: 1400, h: 788, caption: "কলা ভবন"},
  21: {w: 1600, h: 800, caption: "মুরারিচাঁদ কবিতা পরিষদ"},
};

// বড় করে দেখানোর ক্রম (dur = ফ্রেম)। style = ছবি আসা-যাওয়ার ধরন
export type HeroStyle = "slideL" | "slideR" | "slideU" | "slideD" | "zoomIn" | "zoomOut" | "rotate" | "flip";
export const HEROES: {ids: number[]; dur: number; style: HeroStyle}[] = [
  {ids: [10], dur: 38, style: "zoomOut"}, // কলেজ গেইট
  {ids: [15, 14], dur: 34, style: "slideL"},
  {ids: [2, 1], dur: 34, style: "slideD"},
  {ids: [21], dur: 34, style: "slideR"}, // কবিতা পরিষদ
  {ids: [3, 5], dur: 34, style: "flip"},
  {ids: [7], dur: 34, style: "zoomIn"}, // রাষ্ট্রবিজ্ঞান ভবন
  {ids: [12, 17], dur: 34, style: "slideU"}, // লম্বা ছবি জোড়ায়
  {ids: [20], dur: 34, style: "rotate"},
  {ids: [13, 16], dur: 34, style: "slideL"}, // লম্বা ছবি জোড়ায়
  {ids: [9], dur: 34, style: "slideU"},
  {ids: [4], dur: 34, style: "flip"}, // বড় ছবি
  {ids: [11], dur: 34, style: "zoomOut"}, // বড় ছবি
];

export const OVERLAP = 12;
export const GALLERY_FRAMES = 550; // ভয়েসের সাথে মেলানো, বদলাবেন না

// শেষ ধাপ: সব ছবি গ্যালারি হয়ে বসে (গ্যালারি সিনের ভেতরের ফ্রেম)
export const MOSAIC_START = 408;
export const MOSAIC = {
  top: [11, 14, 15, 19, 3, 8, 12, 2], // ওপরের সারি: বামে স্লাইড
  bottom: [6, 13, 16, 17, 1, 5, 18, 4], // নিচের সারি: ডানে স্লাইড
  left: [3, 12, 15, 2, 8, 17], // বামের কলাম: ওপরে স্লাইড
  right: [17, 14, 19, 16, 5, 13], // ডানের কলাম: নিচে স্লাইড
};
// মাঝখানের বড় ছবি (start = মোজাইক ফ্রেমে কখন আসবে)
export const CENTER: {id: number; start: number; style: HeroStyle}[] = [
  {id: 21, start: 0, style: "zoomOut"},
  {id: 7, start: 48, style: "slideL"},
  {id: 10, start: 96, style: "flip"},
];
