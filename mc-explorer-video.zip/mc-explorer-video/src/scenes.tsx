import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {PhoneFrame, TapSpec} from "./PhoneFrame";
import {C, SITE_LABEL} from "./theme";
import {GradText, LogoTile, Pill, Rise, Scene, bn} from "./ui";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const center: React.CSSProperties = {justifyContent: "center", alignItems: "center", textAlign: "center"};

/* ১) হুক */
export const HookScene: React.FC = () => {
  const f = useCurrentFrame();
  const chips = [
    {t: "১০টি প্রশ্ন", x: 90, y: 90},
    {t: "স্কোর কার্ড", x: 930, y: 80},
    {t: "লিডারবোর্ড", x: 60, y: 560},
    {t: "চ্যাট", x: 1000, y: 540},
    {t: "সার্ভে", x: 440, y: 630},
    {t: "সাপ্তাহিক লটারি", x: 700, y: 120},
  ];
  return (
    <Scene>
      {chips.map((c, i) => (
        <div
          key={c.t}
          style={{
            position: "absolute",
            left: c.x,
            top: c.y + Math.sin((f + i * 20) / 15) * 8,
            opacity: 0.3,
            filter: "blur(1px)",
          }}
        >
          <Pill style={{fontSize: 20, padding: "10px 20px"}}>{c.t}</Pill>
        </div>
      ))}
      <AbsoluteFill style={{...center, gap: 22}}>
        <Rise>
          <Pill>🎓 মুরারিচাঁদ কলেজ, সিলেট</Pill>
        </Rise>
        <Rise delay={6}>
          <div style={{fontSize: 72, fontWeight: 700, lineHeight: 1.25, color: C.text}}>
            তুমি এম.সি
            <br />
            <GradText>কতটুকু চেনো?</GradText>
          </div>
        </Rise>
        <Rise delay={18}>
          <div style={{fontSize: 24, color: C.muted}}>১০টি প্রশ্নে স্কোর জানো, কার্ড শেয়ার করো, বন্ধুকে চ্যালেঞ্জ দাও</div>
        </Rise>
      </AbsoluteFill>
    </Scene>
  );
};

/* ২) ইন্ট্রো */
export const IntroScene: React.FC = () => {
  const f = useCurrentFrame();
  const glow = interpolate(f, [0, 40], [0, 1], clamp);
  return (
    <Scene>
      <AbsoluteFill style={{...center, gap: 22}}>
        <Rise>
          <Pill>✦ INTRODUCING</Pill>
        </Rise>
        <Rise delay={6} from={30}>
          <div style={{display: "flex", alignItems: "center", gap: 28, opacity: 0.4 + glow * 0.6}}>
            <LogoTile size={130} />
            <div style={{fontSize: 96, fontWeight: 700, color: C.text}}>
              MC <GradText>Explorer</GradText>
            </div>
          </div>
        </Rise>
        <Rise delay={20}>
          <div style={{fontSize: 26, color: C.muted}}>এম.সি কলেজকে নতুন করে চেনার কুইজ চ্যালেঞ্জ</div>
        </Rise>
      </AbsoluteFill>
    </Scene>
  );
};

/* সাইট ট্যুর: বাম পাশে লেখা, ডান পাশে ফোনে আসল স্ক্রিনশট */
const Section: React.FC<{
  shot: string;
  kicker: string;
  title: React.ReactNode;
  desc: string;
  chips?: string[];
  tilt?: number;
  tap?: TapSpec;
  children?: React.ReactNode;
}> = ({shot, kicker, title, desc, chips = [], tilt = 0, tap, children}) => (
  <Scene>
    <AbsoluteFill style={{flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 90}}>
      <div style={{width: 560, display: "flex", flexDirection: "column", gap: 18, alignItems: "flex-start"}}>
        <Rise>
          <Pill>{kicker}</Pill>
        </Rise>
        <Rise delay={6}>
          <div style={{fontSize: 50, fontWeight: 700, lineHeight: 1.3, color: C.text}}>{title}</div>
        </Rise>
        <Rise delay={14}>
          <div style={{fontSize: 21, lineHeight: 1.6, color: C.muted}}>{desc}</div>
        </Rise>
        {chips.length > 0 && (
          <Rise delay={22}>
            <div style={{display: "flex", gap: 8, flexWrap: "wrap"}}>
              {chips.map((c) => (
                <Pill key={c}>{c}</Pill>
              ))}
            </div>
          </Rise>
        )}
        {children}
      </div>
      <PhoneFrame shot={shot} tilt={tilt} tap={tap} />
    </AbsoluteFill>
  </Scene>
);

export const HomeScene: React.FC = () => (
  <Section
    shot="home"
    tap={{x: 0.5, y: 0.845, at: 44}}
    kicker="🏠 হোম"
    title={
      <>
        নাম দাও, <GradText>খেলা শুরু করো</GradText>
      </>
    }
    desc="ছাত্র, ছাত্রী, স্যার, ম্যাম বা ভিজিটর — নিজের পরিচয় বেছে নাও। বিভাগ ও ব্যাচ দিয়ে এক ট্যাপে শুরু।"
    chips={["বিভাগ", "ব্যাচ (সেশন)", "ঐচ্ছিক ক্লাব ও ছবি"]}
    tilt={-2}
  />
);

export const RulesScene: React.FC = () => (
  <Section
    shot="rules"
    tap={{x: 0.5, y: 0.823, at: 60}}
    kicker="🎯 খেলার নিয়ম ও পুরস্কার"
    title={
      <>
        <GradText>১০টি প্রশ্ন</GradText>, প্রতিটিতে ২০ সেকেন্ড
      </>
    }
    desc="ছবি কোনা থেকে ধীরে ধীরে খোলে — যত তাড়াতাড়ি চিনবে, তত বেশি নম্বর। প্রতি প্রশ্নে সর্বোচ্চ ১০০, প্রতি সেকেন্ডে ৫ নম্বর কাটা যায়।"
    chips={["ভুল বা স্কিপ = ০", "মোট ১০০০ নম্বর", "ব্যাজসহ কার্ড"]}
    tilt={2}
  />
);

export const QuizScene: React.FC = () => (
  <Section
    shot="quiz"
    tap={{x: 0.5, y: 0.76, at: 44}}
    kicker="❓ কুইজ"
    title={
      <>
        ছবি দেখে <GradText>জায়গা চেনো</GradText>
      </>
    }
    desc="কলেজের কোনো জায়গার ছবি দেখে চার অপশন থেকে সঠিকটা বেছে নাও। লাইভ স্কোর আর স্কিপ করার সুবিধা আছে।"
    chips={["লাইভ স্কোর", "চার অপশন", "স্কিপ"]}
    tilt={-2}
  />
);

export const ResultScene: React.FC = () => (
  <Section
    shot="result"
    tap={{x: 0.27, y: 0.832, at: 44}}
    kicker="🪪 আমার কার্ড"
    title={
      <>
        তোমার ফল, <GradText>তোমার ব্যাজ</GradText>
      </>
    }
    desc="খেলা শেষে নম্বর অনুযায়ী ব্যাজসহ স্কোর কার্ড পাবে — শেয়ার বা ডাউনলোড করো, স্টোরি সাইজও বানাতে পারবে।"
    chips={["M.C PLATINUM", "M.C DIAMOND", "শেয়ার", "ডাউনলোড"]}
    tilt={2}
  />
);

export const BoardScene: React.FC = () => (
  <Section
    shot="board"
    tap={{x: 0.5, y: 0.78, at: 44}}
    kicker="🏆 লিডারবোর্ড"
    title={
      <>
        কে <GradText>সবার সেরা?</GradText>
      </>
    }
    desc="সেরা ৩ জনের কার্ডসহ র‍্যাংকিং, আর সঙ্গে বিভাগ অনুযায়ী গড় শতাংশ — দেখো তোমার বিভাগ কত এগিয়ে।"
    chips={["সেরা ৩ জন", "বিভাগভিত্তিক গড়", "তোমার র‍্যাংক"]}
    tilt={-2}
  />
);

/* চ্যাট ও সার্ভে: স্ক্রিনশট না থাকায় শুধু টেক্সট কার্ড */
export const MoreScene: React.FC = () => {
  const items = [
    {i: "💬", t: "চ্যাট", d: "কলেজ নিয়ে সবার সাথে কথা বলো"},
    {i: "📊", t: "সার্ভে", d: "ছোট্ট সার্ভেতে তোমার মতামত জানাও"},
  ];
  return (
    <Scene>
      <AbsoluteFill style={{...center, gap: 26}}>
        <Rise>
          <div style={{fontSize: 58, fontWeight: 700, color: C.text}}>
            আরও আছে <GradText>চ্যাট ও সার্ভে</GradText>
          </div>
        </Rise>
        <div style={{display: "flex", gap: 24}}>
          {items.map((x, k) => (
            <Rise key={x.t} delay={12 + k * 10}>
              <div
                style={{
                  width: 360,
                  padding: "28px 24px",
                  borderRadius: 22,
                  background: C.card,
                  border: `1px solid ${C.border}`,
                  color: C.text,
                }}
              >
                <div style={{fontSize: 54}}>{x.i}</div>
                <div style={{fontSize: 34, fontWeight: 700, margin: "6px 0"}}>{x.t}</div>
                <div style={{fontSize: 20, color: C.muted}}>{x.d}</div>
              </div>
            </Rise>
          ))}
        </div>
      </AbsoluteFill>
    </Scene>
  );
};

/* পুরস্কার: জমা দেওয়ার নিয়ম */
export const PrizeScene: React.FC = () => {
  const f = useCurrentFrame();
  const n = Math.round(interpolate(f, [10, 40], [0, 5], clamp));
  const steps = [
    {i: "⬇️", t: "কার্ড ডাউনলোড করো"},
    {i: "📘", t: "ফেসবুকে পাবলিক পোস্ট করো, সাইটের লিংকসহ"},
    {i: "📝", t: "নাম, পোস্টের লিংক আর স্ক্রিনশট জমা দাও"},
  ];
  return (
    <Section
      shot="submit"
    tap={{x: 0.5, y: 0.42, at: 50}}
      kicker="🎁 পুরস্কার"
      title={
        <>
          প্রতি সপ্তাহে <GradText>{bn(n)} জন বিজয়ী</GradText>
        </>
      }
      desc="লটারির মাধ্যমে বিজয়ী নির্বাচন। জমা দেওয়ার সহজ নিয়ম:"
      tilt={2}
    >
      <div style={{display: "flex", flexDirection: "column", gap: 10, width: "100%"}}>
        {steps.map((s, i) => (
          <Rise key={s.t} delay={24 + i * 10} from={16}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 14,
                padding: "12px 16px",
                borderRadius: 16,
                background: C.card,
                border: `1px solid ${C.border}`,
                color: C.text,
                fontSize: 21,
                fontWeight: 600,
              }}
            >
              <span style={{fontSize: 28}}>{s.i}</span>
              <span>
                {bn(i + 1)}. {s.t}
              </span>
            </div>
          </Rise>
        ))}
      </div>
    </Section>
  );
};

/* ট্রাস্ট নোট */
export const TrustScene: React.FC = () => (
  <Scene>
    <AbsoluteFill style={{...center, gap: 22}}>
      <Rise>
        <LogoTile size={120} />
      </Rise>
      <Rise delay={8}>
        <div style={{fontSize: 56, fontWeight: 700, color: C.text}}>
          শিক্ষার্থীদের <GradText>উদ্যোগে তৈরি</GradText>
        </div>
      </Rise>
      <Rise delay={18}>
        <div style={{fontSize: 24, color: C.muted}}>এটি কলেজের অফিসিয়াল সাইট নয় — শিক্ষার্থীদের হাতে, শিক্ষার্থীদের জন্য</div>
      </Rise>
    </AbsoluteFill>
  </Scene>
);

/* CTA */
export const CtaScene: React.FC = () => {
  const f = useCurrentFrame();
  const chars = Math.floor(interpolate(f, [20, 70], [0, SITE_LABEL.length], clamp));
  const caret = Math.floor(f / 12) % 2 === 0 ? "|" : " ";
  return (
    <Scene>
      <AbsoluteFill style={{...center, gap: 22}}>
        <Rise>
          <div style={{display: "flex", alignItems: "center", gap: 22}}>
            <LogoTile size={92} />
            <div style={{fontSize: 74, fontWeight: 700, color: C.text}}>
              MC <GradText>Explorer</GradText>
            </div>
          </div>
        </Rise>
        <Rise delay={8}>
          <div style={{fontSize: 40, fontWeight: 700, color: C.text}}>এখনই খেলো, জিতে নাও পুরস্কার</div>
        </Rise>
        <Rise delay={14}>
          <div style={{display: "flex", alignItems: "center", gap: 14}}>
            <div
              style={{
                padding: "14px 24px",
                borderRadius: 14,
                background: C.card,
                border: `1px solid ${C.border}`,
                color: C.text,
                fontSize: 26,
                minWidth: 360,
                textAlign: "left",
              }}
            >
              {SITE_LABEL.slice(0, chars)}
              {caret}
            </div>
            <div
              style={{
                padding: "14px 26px",
                borderRadius: 14,
                background: `linear-gradient(90deg, ${C.pink}, #e11d48)`,
                color: "#fff",
                fontSize: 24,
                fontWeight: 700,
              }}
            >
              MC কতটুকু চেনো?
            </div>
          </div>
        </Rise>
        <Rise delay={30}>
          <div style={{fontSize: 18, color: C.muted}}>হোম · আমার কার্ড · লিডারবোর্ড · চ্যাট · সার্ভে</div>
        </Rise>
      </AbsoluteFill>
    </Scene>
  );
};
