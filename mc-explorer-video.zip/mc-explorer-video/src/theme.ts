// ============ এখানে সব সেটিংস বদলানো যায় ============

export const SITE_URL = "https://mc-explorer.top";
export const SITE_LABEL = "mc-explorer.top";

// ভিডিওর রঙ (আসল সাইটের সবুজ + হলুদ + গোলাপি বাটন)
export const C = {
  bg1: "#03120b",
  bg2: "#0c3a26",
  accent: "#34d399",
  accent2: "#a3e635",
  gold: "#fcd34d",
  gold2: "#f59e0b",
  pink: "#f43f5e",
  text: "#f1f5f2",
  muted: "#a9c0b2",
  card: "rgba(255,255,255,0.07)",
  border: "rgba(255,255,255,0.16)",
};

import {GALLERY_FRAMES} from "./photos";

export const FPS = 30;

// প্রতিটি সিনের দৈর্ঘ্য (ফ্রেম, 30fps)
export const DURATIONS = {
  hook: 100,
  intro: 90,
  gallery: GALLERY_FRAMES,
  home: 175,
  rules: 170,
  quiz: 140,
  result: 170,
  board: 140,
  more: 110,
  prize: 195,
  trust: 90,
  cta: 170,
};

// পুরস্কার সিন কখন শুরু (গ্লোবাল ফ্রেম) ও কার্ড সীল মারার মুহূর্ত (সিনের ভেতরের ফ্রেম)
export const PRIZE_START =
  DURATIONS.hook + DURATIONS.intro + DURATIONS.gallery + DURATIONS.home + DURATIONS.rules +
  DURATIONS.quiz + DURATIONS.result + DURATIONS.board + DURATIONS.more;
export const STAMP_AT = [72, 115]; // ভয়েসের বিরতির ভেতরে পড়ে // [স্কোর কার্ড, স্টোরি কার্ড]

export const TOTAL = Object.values(DURATIONS).reduce((a, b) => a + b, 0);
