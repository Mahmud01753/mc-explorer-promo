// ============ এখানে সব সেটিংস বদলানো যায় ============

export const SITE_URL = "https://mc-explorer.top";
export const SITE_LABEL = "mc-explorer.top";

// ভিডিওর রঙ (আসল সাইটের সবুজ + হলুদ + গোলাপি বাটন)
export const C = {
  bg1: "#03120b",
  bg2: "#0c3a26",
  accent: "#34d399",
  accent2: "#a3e635",
  gold: "#fcd34d",
  gold2: "#f59e0b",
  pink: "#f43f5e",
  text: "#f1f5f2",
  muted: "#a9c0b2",
  card: "rgba(255,255,255,0.07)",
  border: "rgba(255,255,255,0.16)",
};

import {GALLERY_FRAMES} from "./photos";

export const FPS = 30;

// প্রতিটি সিনের দৈর্ঘ্য (ফ্রেম, 30fps)
export const DURATIONS = {
  hook: 100,
  intro: 90,
  gallery: GALLERY_FRAMES,
  home: 130,
  rules: 170,
  quiz: 140,
  result: 140,
  board: 140,
  more: 110,
  prize: 150,
  trust: 90,
  cta: 140,
};

export const TOTAL = Object.values(DURATIONS).reduce((a, b) => a + b, 0);
