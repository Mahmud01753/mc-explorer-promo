import React from "react";
import {
  AbsoluteFill,
  Img,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import {loadFont} from "@remotion/google-fonts/HindSiliguri";
import {C} from "./theme";

const {fontFamily} = loadFont("normal", {
  weights: ["400", "600", "700"],
  subsets: ["bengali", "latin"],
});
export const FONT = `${fontFamily}, "Noto Sans Bengali", sans-serif`;

// ইংরেজি সংখ্যা -> বাংলা সংখ্যা
export const bn = (n: number | string) =>
  String(n).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

export const Background: React.FC = () => {
  const f = useCurrentFrame();
  const s = (k: number) => Math.sin(f / k);
  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(120% 90% at 50% 0%, ${C.bg2}, ${C.bg1} 70%)`,
        fontFamily: FONT,
        overflow: "hidden",
      }}
    >
      <div
        style={{
          position: "absolute",
          width: 760,
          height: 760,
          borderRadius: "50%",
          left: -200 + s(70) * 50,
          top: -260 + s(90) * 30,
          background: `radial-gradient(circle, ${C.accent}30, transparent 65%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 640,
          height: 640,
          borderRadius: "50%",
          right: -180 + s(80) * 40,
          bottom: -260 + s(60) * 30,
          background: `radial-gradient(circle, ${C.accent2}22, transparent 65%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          bottom: 0,
          height: 280,
          backgroundImage: `linear-gradient(${C.border} 1px, transparent 1px), linear-gradient(90deg, ${C.border} 1px, transparent 1px)`,
          backgroundSize: "64px 64px",
          backgroundPosition: `0 ${(f * 0.6) % 64}px`,
          opacity: 0.35,
          WebkitMaskImage: "linear-gradient(to top, black, transparent)",
          maskImage: "linear-gradient(to top, black, transparent)",
        }}
      />
    </AbsoluteFill>
  );
};

// সিনের শুরু ও শেষে ফেড
export const Scene: React.FC<{children: React.ReactNode}> = ({children}) => {
  const f = useCurrentFrame();
  const {durationInFrames: d} = useVideoConfig();
  const o = interpolate(f, [0, 10, d - 10, d], [0, 1, 1, 0], clamp);
  return <AbsoluteFill style={{opacity: o, fontFamily: FONT}}>{children}</AbsoluteFill>;
};

// নিচ থেকে উঠে আসা অ্যানিমেশন
export const Rise: React.FC<{
  delay?: number;
  from?: number;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({delay = 0, from = 24, style, children}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f - delay, fps, config: {damping: 200}});
  return (
    <div style={{opacity: s, transform: `translateY(${(1 - s) * from}px)`, ...style}}>
      {children}
    </div>
  );
};

export const GradText: React.FC<{children: React.ReactNode}> = ({children}) => (
  <span
    style={{
      background: `linear-gradient(90deg, ${C.gold}, ${C.gold2})`,
      WebkitBackgroundClip: "text",
      backgroundClip: "text",
      color: "transparent",
    }}
  >
    {children}
  </span>
);

export const Pill: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({
  children,
  style,
}) => (
  <span
    style={{
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      padding: "6px 14px",
      borderRadius: 999,
      background: C.card,
      border: `1px solid ${C.border}`,
      color: C.muted,
      fontSize: 16,
      ...style,
    }}
  >
    {children}
  </span>
);

// লোগোর কোণ আগে থেকেই গোল ও স্বচ্ছ, তাই আলাদা রেডিয়াস লাগে না
export const LogoTile: React.FC<{size?: number}> = ({size = 96}) => (
  <Img
    src={staticFile("logo.png")}
    style={{
      width: size,
      height: size,
      objectFit: "contain",
      filter: `drop-shadow(0 0 ${size * 0.3}px ${C.gold}66)`,
    }}
  />
);

// পুরো ভিডিওতে বাম-ওপরের কোণে লোগো (প্রথম ফ্রেম থেকে শেষ পর্যন্ত)
export const LogoBug: React.FC = () => {
  const f = useCurrentFrame();
  const o = interpolate(f, [0, 12], [0, 1], clamp);
  const s = interpolate(f, [0, 12], [0.7, 1], clamp);
  return (
    <div
      style={{
        position: "absolute",
        top: 14,
        left: 18,
        opacity: o,
        transform: `scale(${s})`,
        transformOrigin: "top left",
        pointerEvents: "none",
      }}
    >
      <LogoTile size={72} />
    </div>
  );
};
