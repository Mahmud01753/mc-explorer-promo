# MC Explorer — ELITE Remotion Video (127 sec, 9:16)

World-class ad-style motion graphics version, built on the PRO version.
Same content, audio, images and logos — motion is upgraded, not the facts.

- Duration: 127.1 sec, 30 fps, 3811 frames, 1080x1920
- Audio: public/mixed.mp3 only (127.056 sec: 10-section Bengali voice, 117.456 sec, + 40 sec music looped and ducked). Do NOT add separate voice/bg music.
- Images + logos: from the site zip, in public/img/ (logo-explorer, logo-card-explorer, logo-mc, og.jpg, gate1/gate2, aerial, academic, map, library, mohona, kola1, chem, admin, chatro, kola2, pond, jarul).
- Elite motion: 3D camera (rotateY + scale + blur in/out), layered parallax (background slowest, glow blobs mid, text fastest), Ken Burns zoom + rotation, expanding logo ring + spring logo pop with rotation, word-by-word title animation, rotateX point cards staggered one by one, animated counters (1000 points, 5 winners), pulsing CTA button on the last slide, slide number 01/10, gradient progress bar, top brand strip.
- Slides (10): Intro, Home setup, Guess the Place, Other games, My Card + Bronze-to-Legend, Fun titles, Leaderboard, Chat + Survey, Weekly lottery 5 winners, CTA + student-initiative disclaimer (not the college's official site; no specific prize claimed).

## Render (GitHub Actions)
Upload files at the repository root (not in a subfolder), Actions > Render MC Explorer > Run workflow, download mc-explorer-mp4 artifact: out/mc-explorer.mp4.

## Render (Codespaces)
```
npm install
npm start
npm run build
```
Output: out/mc-explorer.mp4. Entry: src/RemotionRoot.tsx (TypeScript-checked).
