import React from 'react';
import { AbsoluteFill, Audio, Img, interpolate, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';

type SlideData = {
  from: number;
  duration: number;
  index: number;
  badge: string;
  title: string;
  subtitle: string;
  points: string[];
  image: string;
  accent: string;
  logo?: string;
  counter?: number;
  counterLabel?: string;
};

const Slide: React.FC<{ s: SlideData }> = ({ s }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const d = s.duration;
  // 3D camera transition: rotateY + scale + blur in/out (world-class ad style)
  const rotateY = interpolate(frame, [0, 26, d - 26, d], [28, 0, 0, -28], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const x = interpolate(frame, [0, 26, d - 26, d], [1080, 0, 0, -1080], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const scale = interpolate(frame, [0, 26, d - 26, d], [0.92, 1, 1, 0.92], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const blur = interpolate(frame, [0, 18, d - 18, d], [14, 0, 0, 14], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const fade = interpolate(frame, [0, 12, d - 12, d], [0, 1, 1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  // Layered parallax: background moves slowest, blobs mid, text fastest
  const zoom = interpolate(frame, [0, d], [1.0, 1.28]);
  const bgY = interpolate(frame, [0, d], [0, -50]);
  const bgRotate = interpolate(frame, [0, d], [0, 2]);
  const blobX = Math.sin((frame / fps) * 0.6) * 40;
  const blobY = Math.cos((frame / fps) * 0.45) * 30;
  const glow = 0.7 + 0.3 * Math.sin((frame / fps) * Math.PI);
  const logoSpring = spring({ frame: frame - 6, fps, config: { damping: 11, mass: 0.9 } });
  const logoRotate = interpolate(frame, [0, 30], [-20, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const ringScale = interpolate(frame, [6, 50], [0.4, 1.6], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const ringOpacity = interpolate(frame, [6, 50], [0.8, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const progress = interpolate(frame, [0, d], [0, 100], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const counter = s.counter ? Math.round(interpolate(frame, [30, Math.min(110, d - 20)], [0, s.counter], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })) : 0;
  const pulse = 1 + 0.05 * Math.sin((frame / fps) * Math.PI * 2);
  const lines = s.title.split('\n');
  return (
    <AbsoluteFill style={{ perspective: 1400, overflow: 'hidden', backgroundColor: '#0f172a' }}>
      <AbsoluteFill style={{ transform: `translateX(${x}px) scale(${scale}) rotateY(${rotateY}deg)`, filter: `blur(${blur}px)`, opacity: fade }}>
        {/* Background photo: Ken Burns + slow rotation */}
        <AbsoluteFill style={{ transform: `scale(${zoom}) translateY(${bgY}px) rotate(${bgRotate}deg)` }}>
          <Img src={staticFile(s.image)} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        </AbsoluteFill>
        {/* Cinematic gradient + animated glow blobs */}
        <AbsoluteFill style={{ background: 'linear-gradient(180deg, rgba(0,0,0,0.30) 0%, rgba(0,0,0,0.55) 45%, rgba(0,0,0,0.94) 100%)' }} />
        <AbsoluteFill style={{ transform: `translate(${blobX}px, ${blobY}px)`, background: `radial-gradient(circle at 85% 15%, ${s.accent}66 0%, transparent 55%)`, opacity: glow }} />
        <AbsoluteFill style={{ transform: `translate(${-blobX}px, ${-blobY}px)`, background: `radial-gradient(circle at 10% 90%, ${s.accent}44 0%, transparent 50%)`, opacity: 0.8 }} />
        {/* Content */}
        <AbsoluteFill style={{ padding: 80, justifyContent: 'flex-end', paddingBottom: 130 }}>
          {s.logo ? (
            <div style={{ position: 'relative', width: 200, height: 200, marginBottom: 20 }}>
              <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: `3px solid ${s.accent}`, transform: `scale(${ringScale})`, opacity: ringOpacity }} />
              <Img src={staticFile(s.logo)} style={{ width: 190, height: 190, objectFit: 'contain', transform: `scale(${logoSpring}) rotate(${logoRotate}deg)`, filter: 'drop-shadow(0 14px 34px rgba(0,0,0,0.65))' }} />
            </div>
          ) : null}
          <div style={{ backgroundColor: s.accent, color: '#052e16', fontWeight: 800, fontSize: 28, padding: '14px 28px', borderRadius: 99, alignSelf: 'flex-start', boxShadow: '0 12px 34px rgba(0,0,0,0.5)', transform: `translateY(${interpolate(frame, [10, 26], [30, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px)` }}>{s.badge}</div>
          <h1 style={{ fontSize: 104, lineHeight: 1.12, marginTop: 36, marginBottom: 0, color: 'white', fontFamily: "'Noto Sans Bengali', sans-serif", textShadow: '0 8px 34px rgba(0,0,0,0.75)' }}>
            {lines.map((line, li) => {
              const delay = 16 + li * 10;
              const w = spring({ frame: frame - delay, fps, config: { damping: 100 } });
              const o = interpolate(frame, [delay, delay + 12], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
              return (
                <span key={line} style={{ display: 'block', transform: `translateY(${(1 - w) * 70}px) scale(${0.9 + w * 0.1})`, opacity: o }}>{line}</span>
              );
            })}
          </h1>
          <p style={{ fontSize: 40, lineHeight: 1.5, color: '#e2e8f0', marginTop: 28, textShadow: '0 4px 20px rgba(0,0,0,0.7)', opacity: interpolate(frame, [30, 44], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }) }}>{s.subtitle}</p>
          {s.counter ? (
            <div style={{ marginTop: 30, display: 'flex', alignItems: 'baseline', gap: 16 }}>
              <span style={{ fontSize: 88, fontWeight: 900, color: s.accent, textShadow: '0 6px 26px rgba(0,0,0,0.7)' }}>{counter}</span>
              <span style={{ fontSize: 32, color: 'white' }}>{s.counterLabel}</span>
            </div>
          ) : null}
          <div style={{ marginTop: 40, display: 'flex', flexDirection: 'column', gap: 20 }}>
            {s.points.map((p, i) => {
              const delay = 36 + i * 14;
              const pSpring = spring({ frame: frame - delay, fps, config: { damping: 100 } });
              const pOpacity = interpolate(frame, [delay, delay + 12], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
              const pRotateX = interpolate(frame, [delay, delay + 18], [35, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
              return (
                <div key={p} style={{ backgroundColor: 'rgba(255,255,255,0.15)', border: `1px solid ${s.accent}88`, borderLeft: `10px solid ${s.accent}`, borderRadius: 22, padding: '24px 30px', fontSize: 34, color: 'white', transform: `translateY(${(1 - pSpring) * 55}px) rotateX(${pRotateX}deg)`, opacity: pOpacity, boxShadow: '0 10px 28px rgba(0,0,0,0.35)' }}>
                  {p}
                </div>
              );
            })}
          </div>
          {s.index === 9 ? (
            <div style={{ marginTop: 36, alignSelf: 'flex-start', backgroundColor: s.accent, color: '#052e16', fontSize: 36, fontWeight: 900, padding: '22px 40px', borderRadius: 99, transform: `scale(${pulse})`, boxShadow: '0 16px 44px rgba(0,0,0,0.55)' }}>এখনই খেলো →</div>
          ) : null}
        </AbsoluteFill>
        {/* Top brand strip + slide number */}
        <AbsoluteFill style={{ padding: 60, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <Img src={staticFile('img/logo-explorer.png')} style={{ width: 64, height: 64, objectFit: 'contain' }} />
            <span style={{ color: 'white', fontSize: 26, fontWeight: 800, letterSpacing: 2, textShadow: '0 4px 16px rgba(0,0,0,0.8)' }}>MC EXPLORER</span>
          </div>
          <span style={{ color: 'white', fontSize: 28, fontWeight: 800, backgroundColor: 'rgba(0,0,0,0.45)', padding: '10px 20px', borderRadius: 99 }}>{String(s.index + 1).padStart(2, '0')} / 10</span>
        </AbsoluteFill>
        {/* Bottom gradient progress bar */}
        <AbsoluteFill style={{ justifyContent: 'flex-end' }}>
          <div style={{ height: 12, backgroundColor: 'rgba(255,255,255,0.25)' }}>
            <div style={{ height: 12, width: `${progress}%`, background: `linear-gradient(90deg, ${s.accent}, #ffffff)` }} />
          </div>
        </AbsoluteFill>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

const slides: SlideData[] = [
  { from: 0, duration: 257, index: 0, badge: '✦ এমসি এক্সপ্লোরার', title: 'তুমি এম.সি\nকতটুকু চেনো?', subtitle: 'মুরারিচাঁদ কলেজ, সিলেট', points: ['ক্যাম্পাস চিনো / স্কোর করো', 'কার্ড বানাও / বন্ধুকে চ্যালেঞ্জ দাও'], image: 'img/og.jpg', accent: '#22c55e', logo: 'img/logo-explorer.png' },
  { from: 257, duration: 378, index: 1, badge: '🏠 শুরু করো', title: 'নাম, পরিচয়,\nবিভাগ, সেশন', subtitle: 'শুরুটা সহজ, কয়েকটা ট্যাপেই', points: ['নাম দাও', 'ছাত্র / ছাত্রী / স্যার / ম্যাম / ভিজিটর', 'বিভাগ / সেশন / ক্লাব / ছবি'], image: 'img/gate1.jpg', accent: '#f59e0b' },
  { from: 635, duration: 464, index: 2, badge: '🎯 জায়গা চেনো', title: 'ছবি দেখে\nজায়গা চেনো', subtitle: '১০টি প্রশ্ন, প্রতি প্রশ্নে ২০ সেকেন্ড', points: ['ছবি কোণা থেকে ধীরে ধীরে খুলবে', 'প্রতি প্রশ্নে সর্বোচ্চ ১০০ / মোট ১০০০', 'ভুল বা স্কিপ হলে ০'], image: 'img/map.jpg', accent: '#38bdf8', counter: 1000, counterLabel: 'সর্বোচ্চ পয়েন্ট' },
  { from: 1099, duration: 324, index: 3, badge: '🎮 আরো গেম', title: 'জুম, ডিটেইল,\nকুইক ফায়ার', subtitle: 'একটা গেম নয়, চারটা চ্যালেঞ্জ', points: ['জুম চ্যালেঞ্জ — কাছ থেকে ছবি', 'ডিটেইল চ্যালেঞ্জ — জানালা, সাইনবোর্ড', 'কুইক ফায়ার — ৬০ সেকেন্ডে ১০ পয়েন্ট'], image: 'img/aerial.jpg', accent: '#22c55e' },
  { from: 1423, duration: 493, index: 4, badge: '🪪 আমার কার্ড', title: 'স্কোর কার্ড,\nপিএনজি ডাউনলোড', subtitle: 'হাই কোয়ালিটি কার্ড, শেয়ার করার মতো', points: ['% জানি / উপাধি / র‍্যাংক / কিউআর কোড', 'ব্রোঞ্জ / সিলভার / গোল্ড', 'প্লাটিনাম / ডায়মন্ড / লেজেন্ড'], image: 'img/library.jpg', accent: '#fbbf24', logo: 'img/logo-card-explorer.png' },
  { from: 1916, duration: 353, index: 5, badge: '😄 মজার উপাধি', title: 'প্রতিটা কার্ডে\nএকটা উপাধি', subtitle: 'কার্ড শেয়ার করলেই চ্যালেঞ্জ', points: ['ক্যাম্পাসের বস', 'জ্ঞানের অভিযাত্রী', 'ক্যাম্পাস চেনার ওস্তাদ'], image: 'img/mohona.jpg', accent: '#22c55e' },
  { from: 2269, duration: 371, index: 6, badge: '🏆 লিডারবোর্ড', title: 'সেরা কারা,\nদেখে নাও', subtitle: 'সার্চ, ফিল্টার, র‍্যাংক হিস্টরি', points: ['সেরা ৩ জন / সার্চ ও ফিল্টার', 'বিভাগ অনুযায়ী গড় শতাংশ', 'আজকের চ্যালেঞ্জ'], image: 'img/academic.jpg', accent: '#38bdf8' },
  { from: 2640, duration: 452, index: 7, badge: '💬 চ্যাট ও সার্ভে', title: 'আড্ডা আর\nমতামত', subtitle: 'বেনামি চ্যাট, ২টি দ্রুত প্রশ্ন', points: ['বেনামি চ্যাট — বিভাগ ও সেশন', 'ভদ্রভাবে চ্যাট / ব্যক্তিগত তথ্য নয়', 'সার্ভে — ২টি দ্রুত প্রশ্ন / জমা দিলেই ফল'], image: 'img/kola1.jpg', accent: '#f59e0b' },
  { from: 3092, duration: 412, index: 8, badge: '🎁 শেয়ার করে পুরস্কার জেতো', title: 'সাপ্তাহিক\nলটারি', subtitle: 'কার্ড শেয়ার করলেই লটারিতে নাম', points: ['কার্ড / স্টোরি ফেসবুকে শেয়ার করো', 'লিংক আর স্ক্রিনশট জমা দাও', 'প্রতি সপ্তাহে লটারি / ৫ জন বিজয়ী'], image: 'img/pond.jpg', accent: '#fbbf24', counter: 5, counterLabel: 'জন বিজয়ী প্রতি সপ্তাহে' },
  { from: 3504, duration: 307, index: 9, badge: '🚀 এখনই খেলো', title: 'এখনই খেলো!\nএমসি এক্সপ্লোরার', subtitle: 'বন্ধুকে চ্যালেঞ্জ দাও, কার্ড শেয়ার করো', points: ['শিক্ষার্থীদের উদ্যোগে তৈরি', 'কলেজের অফিসিয়াল সাইট নয়'], image: 'img/gate2.jpg', accent: '#22c55e', logo: 'img/logo-explorer.png' },
];

export const MCExplorer: React.FC = () => {
  return (
    <AbsoluteFill style={{ backgroundColor: '#0f172a' }}>
      <Audio src={staticFile('mixed.mp3')} />
      {slides.map((s) => (
        <Sequence key={s.from} from={s.from} durationInFrames={s.duration}>
          <Slide s={s} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
