import { Composition } from 'remotion';
import { MCExplorer } from './Composition';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="MCExplorer"
      component={MCExplorer}
      durationInFrames={3811}
      fps={30}
      width={1080}
      height={1920}
    />
  );
};
